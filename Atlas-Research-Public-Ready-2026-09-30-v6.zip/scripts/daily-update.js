#!/usr/bin/env node

/**
 * Refresh the static Atlas snapshot from public institutional pages.
 *
 * The script deliberately has no third-party dependencies. It extracts the
 * latest RSS/Atom entries when available and otherwise falls back to the
 * newest linked headlines on an institution's public index page. A failed
 * source never erases the last successful snapshot.
 */

const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { TextDecoder } = require("util");

const ROOT = path.resolve(__dirname, "..");
const DATA_FILE = path.join(ROOT, "data", "site-data.js");
const DAILY_DIR = path.join(ROOT, "data", "daily");
const RUN_LOG_DIR = path.join(__dirname, "logs");
const DEFAULT_TIMEOUT = 12_000;

const MARKET_INDICES = [
  { id: "sse", name: "上证指数", secid: "1.000001", unit: "点", region: "中国" },
  { id: "szse", name: "深证成指", secid: "0.399001", unit: "点", region: "中国" },
  { id: "chinext", name: "创业板指", secid: "0.399006", unit: "点", region: "中国" },
  { id: "csi300", name: "沪深300", secid: "1.000300", unit: "点", region: "中国" },
  { id: "hsi", name: "恒生指数", secid: "100.HSI", unit: "点", region: "中国香港" },
  { id: "nasdaq100", name: "纳斯达克100", secid: "100.NDX", unit: "点", region: "美国" },
  { id: "sp500", name: "标普500", secid: "100.SPX", unit: "点", region: "美国" },
  { id: "goldEtf", name: "黄金ETF华安", secid: "1.518880", unit: "元", region: "中国" }
];

const MARKET_API_BASE = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
const MARKET_SOURCE_URL = "https://quote.eastmoney.com/center/";
const MARKET_INDEX_QUOTES = [
  { id: "sse", name: "上证指数", symbol: "sh000001", unit: "点", region: "中国" },
  { id: "szse", name: "深证成指", symbol: "sz399001", unit: "点", region: "中国" },
  { id: "chinext", name: "创业板指", symbol: "sz399006", unit: "点", region: "中国" },
  { id: "csi300", name: "沪深300", symbol: "sh000300", unit: "点", region: "中国" },
  { id: "hsi", name: "恒生指数", symbol: "hkHSI", unit: "点", region: "中国香港" },
  { id: "nasdaq100", name: "纳斯达克100", symbol: "usNDX", unit: "点", region: "美国" },
  { id: "sp500", name: "标普500", symbol: "usINX", unit: "点", region: "美国" },
  { id: "goldEtf", name: "黄金ETF华安", symbol: "sh518880", unit: "元", region: "中国" }
];
const MARKET_LEADERS = [
  { id: "csi-consumption", name: "中证主要消费", symbol: "sh000932", category: "消费指数", region: "中国" },
  { id: "maotai", name: "贵州茅台", symbol: "sh600519", category: "消费", region: "中国" },
  { id: "wuliangye", name: "五粮液", symbol: "sz000858", category: "消费", region: "中国" },
  { id: "yili", name: "伊利股份", symbol: "sh600887", category: "消费", region: "中国" },
  { id: "midea", name: "美的集团", symbol: "sz000333", category: "消费/家电", region: "中国" },
  { id: "nvidia", name: "英伟达", symbol: "usNVDA", category: "全球科技", region: "美国" },
  { id: "apple", name: "苹果", symbol: "usAAPL", category: "全球科技", region: "美国" },
  { id: "microsoft", name: "微软", symbol: "usMSFT", category: "全球科技", region: "美国" },
  { id: "amazon", name: "亚马逊", symbol: "usAMZN", category: "全球科技", region: "美国" },
  { id: "alphabet", name: "谷歌", symbol: "usGOOGL", category: "全球科技", region: "美国" },
  { id: "tesla", name: "特斯拉", symbol: "usTSLA", category: "全球科技", region: "美国" }
];
const MARKET_LEADER_API = "https://qt.gtimg.cn/q=";
const MARKET_LEADER_SOURCE_URL = "https://stock.finance.qq.com/";

function logRun(message) {
  fs.mkdirSync(RUN_LOG_DIR, { recursive: true });
  fs.appendFileSync(path.join(RUN_LOG_DIR, `daily-${new Date().toISOString().slice(0, 10)}.log`), `[${new Date().toISOString()}] ${message}\n`, "utf8");
}

const SOURCES = [
  {
    id: "nbs",
    name: "国家统计局",
    type: "国内官方",
    url: "https://www.stats.gov.cn/sj/zxfb/index.html",
    keywords: ["工业", "消费", "PMI", "投资", "经济", "价格", "房地产"]
  },
  {
    id: "pbc",
    name: "中国人民银行",
    type: "国内官方",
    url: "https://www.pbc.gov.cn/goutongjiaoliu/113456/113469/index.html",
    keywords: ["社融", "贷款", "货币", "利率", "金融", "存款", "流动性"]
  },
  {
    id: "csrc",
    name: "中国证监会",
    type: "监管机构",
    url: "https://www.csrc.gov.cn/csrc/c100028/common_list.shtml",
    keywords: ["监管", "上市公司", "资本市场", "注册制", "投资者"]
  },
  {
    id: "sse",
    name: "上海证券交易所",
    type: "交易所",
    url: "https://www.sse.com.cn/disclosure/listedinfo/announcement/",
    keywords: ["公告", "定期报告", "业绩", "分红", "问询"]
  },
  {
    id: "szse",
    name: "深圳证券交易所",
    type: "交易所",
    url: "https://www.szse.cn/disclosure/listed/notice/index.html",
    keywords: ["公告", "定期报告", "业绩", "问询", "回购"]
  },
  {
    id: "cninfo",
    name: "巨潮资讯",
    type: "上市公司披露",
    url: "https://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search",
    keywords: ["业绩预告", "业绩快报", "年报", "半年报", "公告"]
  },
  {
    id: "imf",
    name: "IMF",
    type: "国际组织",
    url: "https://www.imf.org/en/News/rss?language=eng",
    keywords: ["growth", "inflation", "china", "trade", "rates", "energy", "outlook"]
  },
  {
    id: "oecd",
    name: "OECD",
    type: "国际组织",
    url: "https://www.oecd.org/newsroom/rss.xml",
    keywords: ["growth", "inflation", "china", "trade", "investment", "outlook"]
  },
  {
    id: "caam",
    name: "中国汽车工业协会",
    type: "行业协会",
    url: "https://www.caam.org.cn/chn/3/cate_38/con_5236999.html",
    keywords: ["汽车", "新能源", "产销", "出口", "销量"]
  },
  {
    id: "miit",
    name: "工业和信息化部",
    type: "行业主管部门",
    sourceType: "official",
    url: "https://www.miit.gov.cn/jgsj/index.html",
    keywords: ["制造业", "工业", "新能源", "通信", "有色", "产业"]
  },
  {
    id: "sina-finance-7x24",
    name: "新浪财经 7×24",
    type: "财经媒体",
    sourceType: "media",
    coverage: "国内快讯、政策、市场与海外资产",
    url: "https://finance.sina.com.cn/7x24/",
    keywords: ["央行", "降息", "降准", "社融", "GDP", "PMI", "CPI", "财政", "消费", "房地产", "美联储", "黄金", "原油", "纳斯达克", "芯片", "贸易", "关税", "业绩", "回购"]
  },
  {
    id: "thepaper-finance",
    name: "澎湃新闻·财经",
    type: "财经媒体",
    sourceType: "media",
    coverage: "宏观政策、产业与公司新闻",
    url: "https://www.thepaper.cn/channel_25951",
    keywords: ["经济", "金融", "政策", "消费", "制造业", "房地产", "汽车", "科技", "人工智能", "芯片", "医药", "资本市场", "上市公司", "基金", "黄金"]
  },
  {
    id: "cls-telegraph",
    name: "财联社财经快讯",
    type: "财经媒体",
    sourceType: "media",
    coverage: "盘中快讯、公司公告与行业动态",
    url: "https://www.cls.cn/",
    keywords: ["国务院", "央行", "证监会", "政策", "涨停", "业绩", "预增", "回购", "增持", "减持", "订单", "产能", "锂电", "光伏", "半导体", "AI", "黄金", "原油", "美股", "港股"]
  },
  {
    id: "ths-finance",
    name: "同花顺财经",
    type: "财经媒体",
    sourceType: "media",
    coverage: "宏观、行业、公司与基金资讯",
    url: "https://news.10jqka.com.cn/",
    keywords: ["宏观", "经济", "政策", "央行", "消费", "新能源", "半导体", "人工智能", "医药", "银行", "证券", "保险", "基金", "业绩", "研报", "黄金", "纳斯达克", "美联储"]
  },
  {
    id: "nvidia-ir",
    name: "NVIDIA Investor Relations",
    type: "全球科技",
    url: "https://investor.nvidia.com/financial-info/quarterly-results/default.aspx",
    keywords: ["earnings", "revenue", "data center", "quarter", "fiscal"]
  },
  {
    id: "apple-ir",
    name: "Apple Investor Relations",
    type: "全球科技",
    url: "https://www.apple.com/newsroom/archive/",
    keywords: ["results", "revenue", "iphone", "services", "quarter"]
  },
  {
    id: "microsoft-ir",
    name: "Microsoft Investor Relations",
    type: "全球科技",
    url: "https://www.microsoft.com/en-us/investor/earnings/default.aspx",
    keywords: ["earnings", "revenue", "cloud", "azure", "quarter"]
  },
  {
    id: "tsmc-ir",
    name: "TSMC Investor Relations",
    type: "全球科技",
    url: "https://investor.tsmc.com/english/quarterly-results",
    keywords: ["earnings", "revenue", "quarter", "advanced", "technology"]
  },
  {
    id: "samsung-ir",
    name: "Samsung Electronics IR",
    type: "全球科技",
    url: "https://www.samsung.com/global/ir/financial-information/earnings-release/",
    keywords: ["earnings", "revenue", "semiconductor", "memory", "quarter"]
  },
  {
    id: "sony-ir",
    name: "Sony Group IR",
    type: "全球科技",
    url: "https://www.sony.com/en/SonyInfo/IR/library/presen/er/archive.html",
    keywords: ["earnings", "revenue", "playstation", "sensor", "quarter"]
  }
];

function parseArgs(argv) {
  const args = { date: new Date().toISOString().slice(0, 10), timeout: DEFAULT_TIMEOUT, dryRun: false };
  for (let i = 0; i < argv.length; i += 1) {
    const value = argv[i];
    if (value === "--date" && argv[i + 1]) args.date = argv[++i];
    else if (value === "--timeout" && argv[i + 1]) args.timeout = Math.max(1000, Number(argv[++i]) || DEFAULT_TIMEOUT);
    else if (value === "--dry-run") args.dryRun = true;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(args.date)) throw new Error("--date must use YYYY-MM-DD");
  return args;
}

function readSiteData() {
  if (!fs.existsSync(DATA_FILE)) throw new Error(`Missing site data file: ${DATA_FILE}`);
  const code = fs.readFileSync(DATA_FILE, "utf8");
  const sandbox = { window: {} };
  vm.runInNewContext(code, sandbox, { filename: DATA_FILE });
  const data = sandbox.window.__INDUSTRY_RESEARCH__ || sandbox.window.__MACRO_WEEKLY_SITE__;
  if (!data || typeof data !== "object") throw new Error("site-data.js did not expose a research object");
  return data;
}

function decodeHtml(input) {
  return String(input || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, "$1")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/\s+/g, " ")
    .trim();
}

function absoluteUrl(href, base) {
  try { return new URL(href, base).href; } catch (_) { return base; }
}

function parseDate(value, fallback) {
  const text = String(value || "").trim();
  const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) {
    const [year, month, day] = iso.slice(1).map(Number);
    const date = new Date(Date.UTC(year, month - 1, day)).toISOString().slice(0, 10);
    return date === text ? date : fallback;
  }
  const parsed = Date.parse(text);
  if (Number.isNaN(parsed)) return fallback;
  return new Date(parsed).toISOString().slice(0, 10);
}

function inferDateFromUrlOrTitle(href, title, fallback) {
  const referenceDate = parseDate(fallback, null);
  const accept = (candidate) => {
    const date = parseDate(candidate, null);
    return date && referenceDate && date <= referenceDate ? { date, estimated: false } : null;
  };

  let pathname = "";
  try { pathname = decodeURIComponent(new URL(href).pathname); } catch (_) {}
  const pathDate = pathname.match(/(?:^|\/)(20\d{2})[-_/]?(0[1-9]|1[0-2])[-_/]?(0[1-9]|[12]\d|3[01])(?=\/|$)/);
  if (pathDate) {
    const candidate = accept(`${pathDate[1]}-${pathDate[2]}-${pathDate[3]}`);
    if (candidate) return candidate;
  }

  const headline = String(title || "").trim();
  const dispatchDate = headline.match(/(?:^|\D)(20\d{2})?年?\s*(0?[1-9]|1[0-2])月\s*(0?[1-9]|[12]\d|3[01])日\s*(?:电|讯)/);
  if (dispatchDate) {
    const year = dispatchDate[1] || referenceDate?.slice(0, 4);
    const candidate = accept(`${year}-${String(dispatchDate[2]).padStart(2, "0")}-${String(dispatchDate[3]).padStart(2, "0")}`);
    if (candidate) return candidate;
  }

  const cnMatch = headline.match(/(20\d{2})年\s*(0?[1-9]|1[0-2])月\s*(0?[1-9]|[12]\d|3[01])日?/);
  if (cnMatch) {
    const candidate = accept(`${cnMatch[1]}-${String(cnMatch[2]).padStart(2, "0")}-${String(cnMatch[3]).padStart(2, "0")}`);
    if (candidate) return candidate;
  }
  return { date: fallback, estimated: true };
}

function isNoiseTitle(title, source) {
  const text = String(title || "").replace(/\s+/g, " ").trim();
  const sourceType = String(source?.type || "");
  if (sourceType === "交易所" && /监管|参与人|市场服务事项|发行上市|公告通知|业务专区|技术支持专区|业务指南|流程|数据$|基金销售机构信息|股东权利网络征集/.test(text)) return true;
  if (/^(交易所|上市公司披露)$/.test(sourceType) && /公开信息|询价交易|匹配成交|大宗交易|行情|质押式回购|质押券折算率|数据服务平台|for overseas clients|深证信|协商成交|盘后定价|申报信息|可转债信息|特定对象发行/i.test(text)) return true;
  if (/^(交易所|上市公司披露)$/.test(sourceType) && /境外投资者持股信息|可充抵保证金证券|股票担保物比例/.test(text)) return true;
  if (/^(交易所|上市公司披露)$/.test(sourceType) && /战略配售股份信息|限制交易与纪律处分|董监高人员股份变动|申请审核进度|信息库|解限与减持/.test(text)) return true;
  if (sourceType === "全球科技" && /^(newsroom|apple stories|apple services|investor relations|home|tv & home|entertainment|accessories|gift cards|apple card|apple pay|apple cash|manage your apple account|apple store account|icloud\.com|apple fitness\+|apple tv\+|apple news|apple news\+|apple podcasts|apple books|apple support|apple id|app store|find a store|genius bar|today at apple|group reservations)$/i.test(text)) return true;
  if (sourceType === "全球科技" && /^(quick read|earnings release)\b/i.test(text)) return true;
  if (sourceType === "全球科技" && /^(presentation|speech transcript)\s*\(earnings\)/i.test(text) && !/20\d{2}|q[1-4]|results|revenue|profit|guidance/i.test(text)) return true;
  if (sourceType === "全球科技" && /apple/i.test(String(source?.name || "")) && !/20\d{2}|earnings|results|report|quarter|revenue|profit|guidance|announc|launch|introduc|available|release|iphone\s*\d+/i.test(text)) return true;
  if (sourceType === "全球科技" && !/earnings|results|revenue|profit|quarter|guidance|sales|growth|launch|introduc|release|acquisition|ai|chip|data center|cloud|iphone|galaxy|semiconductor|dividend|buyback|投资者|财报|业绩|营收|利润|销量|增长/i.test(text)) return true;
  if (sourceType === "全球科技" && text.split(/\s+/).length <= 4 && !/\d{2,}/.test(text)) return true;
  if (sourceType === "全球科技" && /^(support for |webcast pdf|previous results|previous earnings)/i.test(text)) return true;
  return text.length < 8
    || /ICP备|公安备案|公网安备|金信备|版权所有|沪ICP备|京ICP备|粤ICP备|备案号|网站地图|联系我们|登录|注册|首页|上一页|下一页|隐私政策|用户协议/i.test(text)
    || /竞价交易公开信息|大宗交易|不动产基金大宗交易|权益类证券大宗交易/i.test(text)
    || /发行上市一件事|业务专区|交易专区/i.test(text)
    || /^关于.{0,12}(中心|平台|我们)$/.test(text)
    || /^(个人信息保护告知书|公募reits信息|tv & home|entertainment|accessories|iphone|ipad|apple services|apple pay|apple cash|manage your apple account|apple music|apple tv|apple one|apple arcade|apple store account|icloud\.com|apple fitness\+|apple tv\+|apple news|apple podcasts|apple books|apple support|apple id|investor relations|home|news|markets?|最新行情)$/i.test(text)
    || /^(photos|update|press release)\b/i.test(text);
}

function isLowSignalMedia(title, summary) {
  const text = `${title || ""} ${summary || ""}`.toLowerCase();
  return !/(经济|金融|股市|市场|股票|基金|财报|业绩|政策|央行|利率|通胀|消费|产业|科技|芯片|能源|贸易|原油|黄金|债券|美股|港股|a股|纳斯达克|美元|economic|finance|market|stock|earnings|rate|inflation|trade|oil|gold|tech|company|shares|fed)/i.test(text);
}

function sourceCategory(source) {
  if (source.sourceType) return source.sourceType;
  if (source.type === "财经媒体") return "media";
  if (source.type === "全球科技") return "company-ir";
  if (source.type === "国际组织") return "international";
  if (source.type === "行业协会") return "industry-association";
  if (source.type === "交易所" || source.type === "上市公司披露") return "disclosure";
  return "official";
}

function parseFeedEntries(body, source, fetchedDate) {
  const entries = [];
  const itemMatches = body.match(/<(item|entry)\b[\s\S]*?<\/\1>/gi) || [];
  for (const item of itemMatches) {
    const titleMatch = item.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const linkMatch = item.match(/<link[^>]*>([\s\S]*?)<\/link>/i) || item.match(/<link[^>]*href=["']([^"']+)["']/i);
    const dateMatch = item.match(/<(?:pubDate|published|updated|date)[^>]*>([\s\S]*?)<\/(?:pubDate|published|updated|date)>/i);
    const summaryMatch = item.match(/<(?:description|summary|content:encoded)[^>]*>([\s\S]*?)<\/(?:description|summary|content:encoded)>/i);
    const title = decodeHtml(titleMatch?.[1]);
    const summary = decodeHtml(summaryMatch?.[1]).slice(0, 500);
    if (!title || title.length < 4 || isNoiseTitle(title, source) || (source.type === "财经媒体" && isLowSignalMedia(title, summary))) continue;
    const parsedDate = parseDate(decodeHtml(dateMatch?.[1]), null);
    const inferred = parsedDate && parsedDate <= fetchedDate
      ? { date: parsedDate, estimated: false }
      : inferDateFromUrlOrTitle(decodeHtml(linkMatch?.[1]), title, fetchedDate);
    entries.push({
      title,
      summary,
      url: absoluteUrl(decodeHtml(linkMatch?.[1]), source.url),
      date: inferred.date,
      dateEstimated: inferred.estimated
    });
  }
  if (entries.length) return dedupeEntries(entries);

  // Government sites commonly expose a plain HTML list instead of RSS.
  const links = [];
  const linkRegex = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = linkRegex.exec(body))) {
    const title = decodeHtml(match[2]);
    if (title.length >= 6 && !isNoiseTitle(title, source) && !(source.type === "财经媒体" && isLowSignalMedia(title, "")) && !/^首页|登录|注册|更多|English|上一页|下一页$/i.test(title)) {
      const inferred = inferDateFromUrlOrTitle(match[1], title, fetchedDate);
      links.push({ title, summary: "", url: absoluteUrl(match[1], source.url), date: inferred.date, dateEstimated: inferred.estimated });
    }
  }
  return dedupeEntries(links).slice(0, 20);
}

function dedupeEntries(entries) {
  const seen = new Set();
  return entries.filter((entry) => {
    const key = `${entry.url}|${entry.title}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function fetchSource(source, timeout, fetchedDate) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(source.url, {
      signal: controller.signal,
      headers: { "user-agent": "Atlas-Research-DailyUpdater/1.0 (+public-data-only)" }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    // Several Chinese finance portals still serve GBK/GB18030. Decode from
    // the declared charset so headlines do not become replacement characters.
    const buffer = Buffer.from(await response.arrayBuffer());
    const contentType = response.headers.get("content-type") || "";
    const charsetMatch = contentType.match(/charset\s*=\s*["']?([^;"'\s]+)/i);
    const charset = String(charsetMatch?.[1] || "utf-8").toLowerCase().replace("gbk", "gb18030").replace("gb2312", "gb18030");
    let body;
    try { body = new TextDecoder(charset).decode(buffer); }
    catch (_) { body = buffer.toString("utf8"); }
    const entries = parseFeedEntries(body, source, fetchedDate);
    const terms = (source.keywords || []).map((term) => term.toLowerCase());
    const relevant = entries.filter((entry) => terms.some((term) => `${entry.title} ${entry.summary || ""}`.toLowerCase().includes(term)));
    return { source, ok: true, fetchedAt: new Date().toISOString(), entries: (relevant.length ? relevant : entries).slice(0, 5) };
  } catch (error) {
    return { source, ok: false, fetchedAt: new Date().toISOString(), entries: [], error: error.name === "AbortError" ? "请求超时" : error.message };
  } finally {
    clearTimeout(timer);
  }
}

function dateBefore(date, days) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() - days);
  return value.toISOString().slice(0, 10).replace(/-/g, "");
}

function parseKline(value) {
  const [date, open, close, high, low, volume, amount, amplitude, changePct, change] = String(value || "").split(",");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Number(close))) return null;
  return {
    date,
    open: Number(open),
    close: Number(close),
    high: Number(high),
    low: Number(low),
    volume: Number(volume),
    amount: Number(amount),
    changePct: Number(changePct),
    change: Number(change)
  };
}

function marketSeriesMetrics(series) {
  const latest = series.at(-1);
  const prior = series.at(-2);
  const point = (days) => series.length > days ? series.at(-1 - days) : series[0];
  const ret = (from) => from?.close ? ((latest.close / from.close) - 1) * 100 : null;
  return {
    latest,
    previousClose: prior?.close ?? null,
    changePct: latest?.changePct ?? null,
    return5d: ret(point(5)),
    return20d: ret(point(20)),
    high20d: series.length ? Math.max(...series.slice(-20).map((item) => item.high)) : null,
    low20d: series.length ? Math.min(...series.slice(-20).map((item) => item.low)) : null
  };
}

async function mapWithConcurrency(items, limit, worker, gapMs = 350) {
  const output = new Array(items.length);
  let cursor = 0;
  async function runner() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      output[index] = await worker(items[index], index);
      if (gapMs) await new Promise((resolve) => setTimeout(resolve, gapMs));
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runner));
  return output;
}

function marketAnalysis(indices, date, failures = []) {
  const hasNumber = (value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value));
  const byId = Object.fromEntries(indices.map((item) => [item.id, item]));
  const equityIndices = indices.filter((item) => item.id !== "goldEtf" && hasNumber(item.changePct));
  const upCount = equityIndices.filter((item) => Number(item.changePct) > 0).length;
  const breadth = equityIndices.length
    ? `${upCount}/${equityIndices.length} 个跟踪权益指数上涨；这是指数样本，不是全市场个股涨跌家数`
    : "指数样本不足，无法描述市场广度";
  const trendCoverage = equityIndices.filter((item) => hasNumber(item.return5d) && hasNumber(item.return20d));
  const trendUp = trendCoverage.filter((item) => Number(item.return5d) > 0 && Number(item.return20d) > 0).length;
  const riskTone = trendCoverage.length >= 5
    ? trendUp / trendCoverage.length >= 0.65 ? "跟踪指数中期偏强" : trendUp / trendCoverage.length <= 0.35 ? "跟踪指数中期偏弱" : "跟踪指数趋势分化"
    : "趋势未确认";
  const displayIds = ["sse", "chinext", "csi300", "hsi", "nasdaq100", "sp500", "goldEtf"];
  const drivers = displayIds.filter((id) => hasNumber(byId[id]?.changePct)).map((id) => {
    const item = byId[id];
    return `${item.name}${Number(item.changePct) >= 0 ? "上涨" : "下跌"}${Math.abs(Number(item.changePct)).toFixed(2)}%`;
  });
  const conclusion = `${date} 最近交易日收盘：${drivers.join("；") || "可用指数数据不足"}。${riskTone}。仅描述指数价格，不据此推断风险偏好或盈利拐点。`;
  const action = "本快照不提供足以支持买卖判断的估值、成分股广度、利率与盈利预期修正数据。不要仅凭单日涨跌改变定投；决策前核对持有基金估值、组合集中度和资金期限。";
  return {
    asOf: date,
    riskTone,
    conclusion,
    drivers,
    breadth,
    trendCoverage: `${trendCoverage.length}/${equityIndices.length} 个指数具备5日与20日收益`,
    action,
    risk: "指数样本不代表全市场；跨时区收盘不可直接并列为同一时点。成交额、个股涨跌家数、利率、估值和盈利预期未纳入本结论。",
    invalidation: "本页未建立可检验的择时模型，因此不存在由该结论推导的买卖失效点。若后续补齐连续市场广度、估值与盈利预期数据，再设定预注册触发条件。",
    dataQuality: failures.length ? `部分指数获取失败：${failures.join("、")}` : "指数日线全部获取成功",
    failures
  };
}

async function fetchMarketData(date, timeout) {
  const begin = dateBefore(date, 45);
  const end = date.replace(/-/g, "");
  const fields = "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61";
  const fetched = await mapWithConcurrency(MARKET_INDICES, 2, async (config) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const url = `${MARKET_API_BASE}?secid=${encodeURIComponent(config.secid)}&klt=101&fqt=1&beg=${begin}&end=${end}&fields1=f1,f2,f3,f4&fields2=${fields}`;
      const response = await fetch(url, { signal: controller.signal, headers: { "user-agent": "Atlas-Research-DailyUpdater/1.0 (+public-data-only)" } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = await response.json();
      const rows = (payload?.data?.klines || []).map(parseKline).filter(Boolean).slice(-30);
      if (!rows.length) throw new Error("未返回日线");
      const metrics = marketSeriesMetrics(rows);
      return {
        config,
        value: {
          id: config.id,
          name: payload.data.name || config.name,
          asOf: metrics.latest.date,
          retrievedAt: new Date().toISOString(),
          sourceName: "东方财富历史行情接口",
          sourceUrl: MARKET_SOURCE_URL,
          region: config.region,
          unit: config.unit,
          secid: config.secid,
          close: metrics.latest.close,
          open: metrics.latest.open,
          high: metrics.latest.high,
          low: metrics.latest.low,
          volume: metrics.latest.volume,
          amount: metrics.latest.amount,
          change: metrics.latest.change,
          changePct: metrics.changePct,
          return5d: metrics.return5d,
          return20d: metrics.return20d,
          high20d: metrics.high20d,
          low20d: metrics.low20d,
          series: rows.map((row) => ({ date: row.date, close: row.close, changePct: row.changePct }))
        }
      };
    } catch (error) {
      return { config, error: `${config.name}: ${error.name === "AbortError" ? "请求超时" : error.message}` };
    } finally {
      clearTimeout(timer);
    }
  }, 350);
  const indices = fetched.filter((item) => item.value).map((item) => item.value);
  const failures = fetched.filter((item) => item.error).map((item) => item.error);
  const actualDate = indices.map((item) => item.asOf).sort().at(-1) || date;
  if (!indices.length) {
    const fallbackIndices = await fetchIndexQuoteFallback(date, timeout);
    if (fallbackIndices.length) {
      return {
        asOf: fallbackIndices.map((item) => item.asOf).sort().at(-1) || date,
        fetchedAt: new Date().toISOString(),
        source: { name: "腾讯行情公开接口（备用）", url: MARKET_LEADER_SOURCE_URL, endpoint: MARKET_LEADER_API },
        indices: fallbackIndices,
        analysis: marketAnalysis(fallbackIndices, fallbackIndices.map((item) => item.asOf).sort().at(-1) || date, failures),
        status: "fallback",
        failures
      };
    }
  }
  return {
    asOf: actualDate,
    fetchedAt: new Date().toISOString(),
    source: { name: "东方财富历史行情接口", url: MARKET_SOURCE_URL, endpoint: MARKET_API_BASE },
    indices,
    analysis: marketAnalysis(indices, actualDate, failures),
    status: indices.length ? "ok" : "failed",
    failures
  };
}

function quoteDate(value, fallback) {
  const text = String(value || "");
  const ymd = text.match(/(20\d{2})[-/]?(\d{2})[-/]?(\d{2})/);
  return ymd ? `${ymd[1]}-${ymd[2]}-${ymd[3]}` : fallback;
}

function parseLeaderQuote(config, body, fallbackDate) {
  const match = body.match(new RegExp(`v_${config.symbol}="([^"]*)"`));
  if (!match) return null;
  const fields = match[1].split("~");
  const close = Number(fields[3]);
  const previousClose = Number(fields[4]);
  if (!Number.isFinite(close) || !Number.isFinite(previousClose)) return null;
  const change = Number(fields[31]);
  const changePct = Number(fields[32]);
  return {
    id: config.id,
    name: fields[1] || config.name,
    symbol: fields[2] || config.symbol,
    category: config.category,
    region: config.region,
    close,
    previousClose,
    open: Number(fields[5]),
    high: Number(fields[33]),
    low: Number(fields[34]),
    change: Number.isFinite(change) ? change : close - previousClose,
    changePct: Number.isFinite(changePct) ? changePct : ((close / previousClose) - 1) * 100,
    asOf: quoteDate(fields[30], fallbackDate),
    quoteTime: fields[30] || fallbackDate,
    sourceName: "腾讯行情公开接口",
    sourceUrl: MARKET_LEADER_SOURCE_URL
  };
}

function quoteToIndex(config, quote, date) {
  if (!quote) return null;
  return {
    ...quote,
    id: config.id,
    name: quote.name || config.name,
    unit: config.unit,
    region: config.region,
    secid: config.symbol,
    asOf: quote.asOf || date,
    return5d: null,
    return20d: null,
    high20d: null,
    low20d: null,
    series: quote.previousClose ? [{ date: quote.asOf || date, close: quote.previousClose }, { date: quote.asOf || date, close: quote.close }] : []
  };
}

async function fetchIndexQuoteFallback(date, timeout) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const url = `${MARKET_LEADER_API}${MARKET_INDEX_QUOTES.map((item) => item.symbol).join(",")}`;
    const response = await fetch(url, { signal: controller.signal, headers: { "user-agent": "Atlas-Research-DailyUpdater/1.0 (+public-data-only)" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const body = new TextDecoder("gb18030").decode(Buffer.from(await response.arrayBuffer()));
    return MARKET_INDEX_QUOTES.map((config) => quoteToIndex(config, parseLeaderQuote(config, body, date), date)).filter(Boolean).map((item) => ({ ...item, sourceName: "腾讯行情公开接口（备用）", sourceUrl: MARKET_LEADER_SOURCE_URL }));
  } catch (_) {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

function leaderAnalysis(leaders) {
  const average = (items) => items.length ? items.reduce((sum, item) => sum + Number(item.changePct || 0), 0) / items.length : null;
  const consumption = leaders.filter((item) => item.category === "消费" || item.category === "消费/家电" || item.category === "消费指数");
  const tech = leaders.filter((item) => item.category === "全球科技");
  const consumptionAvg = average(consumption);
  const techAvg = average(tech);
  return {
    breadth: leaders.length ? `${leaders.filter((item) => Number(item.changePct) > 0).length}/${leaders.length} 个头部标的上涨` : "头部标的未取得",
    consumption: consumptionAvg === null ? "消费头部行情未取得" : `消费指数与龙头平均${consumptionAvg >= 0 ? "上涨" : "下跌"}${Math.abs(consumptionAvg).toFixed(2)}%`,
    technology: techAvg === null ? "全球科技头部行情未取得" : `全球科技头部平均${techAvg >= 0 ? "上涨" : "下跌"}${Math.abs(techAvg).toFixed(2)}%`,
    consumptionAverage: consumptionAvg,
    technologyAverage: techAvg
  };
}

async function fetchMarketLeaders(date, timeout) {
  const failures = [];
  const leaders = [];
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const url = `${MARKET_LEADER_API}${MARKET_LEADERS.map((item) => item.symbol).join(",")}`;
    const response = await fetch(url, { signal: controller.signal, headers: { "user-agent": "Atlas-Research-DailyUpdater/1.0 (+public-data-only)" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const body = new TextDecoder("gb18030").decode(Buffer.from(await response.arrayBuffer()));
    for (const config of MARKET_LEADERS) {
      const quote = parseLeaderQuote(config, body, date);
      if (quote) leaders.push(quote);
      else failures.push(`${config.name}: 未返回报价`);
    }
  } catch (error) {
    failures.push(error.name === "AbortError" ? "头部行情: 请求超时" : `头部行情: ${error.message}`);
  } finally {
    clearTimeout(timer);
  }
  return {
    asOf: date,
    source: { name: "腾讯行情公开接口", url: MARKET_LEADER_SOURCE_URL, endpoint: MARKET_LEADER_API },
    leaders,
    analysis: leaderAnalysis(leaders),
    status: leaders.length ? "ok" : "failed",
    failures
  };
}

function impactFor() {
  return "方向待核验";
}

function analysisFor() {
  return {
    investmentInsight: "当前自动流程只筛选公开页面标题与摘要，没有核验全文、市场一致预期、资产价格反应或因果关系。该条仅作研究线索，不构成方向判断。",
    opportunity: "待核验：原文事实是否改变收入、成本、供需、资本开支或现金流，并确认影响持续时间。",
    risk: "待核验：反方证据、数据口径、同比基数、一次性因素及市场是否已提前定价。",
    invalidation: "方向判断尚未建立；完成原文和数据交叉核验后再设置观察指标与失效条件。"
  };
}

function topicFor(title) {
  const text = String(title || "").toLowerCase();
  if (/利率|降息|降准|央行|通胀|cpi|ppi|社融|贷款|货币|美联储|欧洲央行|财政/.test(text)) return "宏观政策";
  if (/gdp|经济|pmi|工业|消费|零售|投资|房地产|就业|贸易|关税|原油|黄金|美元/.test(text)) return "宏观数据";
  if (/财报|业绩|营收|利润|预增|回购|增持|减持|订单|签约|产能|指引|earnings|revenue|profit|guidance/.test(text)) return "公司业绩";
  if (/ai|人工智能|芯片|半导体|算力|gpu|云|光伏|锂电|新能源|汽车|医药|有色|煤炭|军工|光刻胶|存储/.test(text)) return "行业景气";
  if (/股市|股票|基金|美股|港股|a股|纳斯达克|指数|债券|市场/.test(text)) return "市场交易";
  return "其他";
}

function importanceFor(event) {
  const sourceWeight = { official: 5, international: 5, media: 3, "company-ir": 4, disclosure: 2, "industry-association": 4 }[event.sourceCategory] || 2;
  const topic = topicFor(event.title);
  const topicWeight = { "宏观政策": 7, "宏观数据": 6, "公司业绩": 7, "行业景气": 6, "市场交易": 4, "其他": 0 }[topic] || 0;
  const text = `${event.title} ${event.detail}`;
  let score = sourceWeight + topicWeight;
  if (event.impact === "偏利好" || event.impact === "偏利空") score += 2;
  if (/[+-]?\d+(\.\d+)?%|[0-9]+\.?[0-9]*万亿|[0-9]+\.?[0-9]*亿元|营收|净利|EPS|revenue|profit/i.test(text)) score += 3;
  if (/预计|决定|正式|发布|突破|创纪录|超预期|下调|上调|风险|冲突|制裁|政策/i.test(text)) score += 2;
  if (/中介机构|投资者教育|持续督导|处罚与处分|持股信息|交易参与人|上市审核|备案|服务事项|导航|支持|overview|previous results/i.test(text)) score -= 8;
  return { score, topic };
}

function makeEvents(results, date) {
  const events = results.flatMap((result) => result.entries.map((entry) => {
    const impact = impactFor(entry.title);
    const category = sourceCategory(result.source);
    return {
      time: entry.date || date,
      publishedAt: entry.dateEstimated ? null : (entry.date || null),
      retrievedAt: result.fetchedAt,
      freshness: entry.dateEstimated ? "发布时间未解析" : (entry.date === date ? "今日发布" : `发布于 ${entry.date}`),
      title: entry.title,
      detail: entry.summary
        ? `${entry.summary}（${entry.dateEstimated ? "发布时间未解析，本次抓取" : `发布于 ${entry.date}，本次抓取于 ${date}`}；建议打开原文核对口径和完整数据。）`
        : `${result.source.name}公开页面条目（${entry.dateEstimated ? "发布时间未解析，本次抓取" : `发布于 ${entry.date}`}；建议打开原文核对口径和完整数据。）`,
      impact,
      reviewStatus: "机器预筛 · 未核验方向",
      source: entry.url,
      sourceName: result.source.name,
      sourceType: result.source.type,
      sourceCategory: category,
      ...analysisFor(entry.title, impact, category),
      ...importanceFor({ title: entry.title, detail: entry.summary || "", impact, sourceCategory: category })
    };
  }));
  const unique = dedupeEntries(events.map((event) => ({ ...event, url: event.source })))
    .map(({ url, ...event }) => event);
  const ranked = unique.sort((left, right) => right.score - left.score || String(right.time).localeCompare(String(left.time)));
  const selected = [];
  const categoryCount = new Map();
  const sourceCount = new Map();
  for (const event of ranked) {
    const category = event.sourceCategory || "official";
    const source = event.sourceName || "未知来源";
    if ((categoryCount.get(category) || 0) >= 4) continue;
    if (event.score < 8 && selected.length >= 8) continue;
    if ((sourceCount.get(source) || 0) >= 3) continue;
    selected.push(event);
    categoryCount.set(category, (categoryCount.get(category) || 0) + 1);
    sourceCount.set(source, (sourceCount.get(source) || 0) + 1);
    if (selected.length >= 12) break;
  }
  return selected;
}

function fallbackEvents(data, date) {
  const opinions = Array.isArray(data.opinions) ? data.opinions.slice(0, 6) : [];
  return opinions.map((item) => {
    const impact = item.stance || "中性";
    const category = "historical";
    return {
      time: item.date || date,
      title: item.title,
      detail: item.summary || "沿用上一版公开机构观点，待下一次抓取确认。",
      impact,
      source: item.source || "https://www.cninfo.com.cn/",
      sourceName: item.institution || "历史快照",
      sourceType: item.type || "历史快照",
      sourceCategory: category,
      ...analysisFor(item.title, impact, category)
    };
  });
}

function buildCompanyDailyUpdates(data, events, date) {
  const companies = Array.isArray(data.companyRankings) ? data.companyRankings : [];
  return companies.map((company) => {
    const match = events.find((event) => String(event.title || "").includes(company.name) || String(event.detail || "").includes(company.code));
    return {
      code: company.code,
      name: company.name,
      industry: company.industry,
      date,
      title: match ? match.title : "本次检查暂无公司级新公告",
      summary: match ? match.detail : "已检查交易所与巨潮资讯公开入口，未解析到以该公司名称标记的新动态；请打开公告页核对。",
      impact: match ? match.impact : "中性",
      source: match ? match.source : company.source,
      sourceName: match ? match.sourceName : "交易所 / 巨潮资讯"
    };
  });
}

function updateGlobalTech(data, results, date) {
  if (!data.globalTech) return;
  const moves = results.filter((result) => result.source.type === "全球科技").flatMap((result) => result.entries.filter((entry) => !entry.dateEstimated).map((entry) => ({
    date: entry.date || date,
    title: entry.title,
    summary: `${result.source.name} IR 页面最新动态，建议打开原文核对财报期、币种和管理层指引。`,
    source: entry.url,
    sourceName: result.source.name
  })));
  if (moves.length) data.globalTech.dailyMoves = dedupeEntries(moves.map((item) => ({ ...item, url: item.source }))).map(({ url, ...item }) => item).slice(0, 8);
  data.globalTech.lastCheckedAt = new Date().toISOString();
  data.globalTech.asOf = data.globalTech.fundamentalsAsOf || null;
  data.globalTech.asOfNote = data.globalTech.fundamentalsAsOf
    ? `财务数据截至 ${data.globalTech.fundamentalsAsOf}`
    : "公司财务快照按各公司披露期标注；日常抓取不代表财务数据已更新";
  data.globalTech.sourceStatus = results.filter((result) => result.source.type === "全球科技").map((result) => ({ name: result.source.name, url: result.source.url, ok: result.ok, error: result.error || null }));
}

function buildCognition(data, events, results, date, usedFallback = false, marketDashboard = null) {
  const todayEvents = events.filter((event) => event.publishedAt === date);
  const eligibleSourceTypes = new Set(["official", "international", "company-ir", "disclosure", "industry-association"]);
  const priorityCandidates = todayEvents.filter((event) => eligibleSourceTypes.has(event.sourceCategory) && event.score >= 15);
  const domesticToday = priorityCandidates.filter((event) => !["IMF", "OECD"].includes(event.sourceName) && event.sourceType !== "全球科技");
  const globalToday = priorityCandidates.filter((event) => ["IMF", "OECD"].includes(event.sourceName) || event.sourceType === "全球科技");
  const noMajorNew = priorityCandidates.length === 0;
  const marketConclusion = marketDashboard?.analysis?.conclusion || "行情数据未取得，不能用新闻标题替代指数走势。";
  const conclusion = noMajorNew
    ? `今日无重大新增。${todayEvents.length ? `仅检出 ${todayEvents.length} 条有明确发布日期的线索，未达到高优先级筛选门槛；` : "未检出有明确发布日期的当日重大新信息；"}较早条目保留原发布日期，不据此调整仓位。`
    : `今日筛出 ${priorityCandidates.length} 条高优先级信息候选。自动流程未核验全文语义、市场预期和价格反应，方向待研究员复核，不将标题当作利好或利空结论。`;
  const stance = noMajorNew ? "中性 · 无重大新增" : "候选信息 · 待核验";
  const assessment = {
    stance,
    summary: conclusion,
    investmentImplication: noMajorNew
      ? "今日抓取没有产生达到筛选门槛的当日新信息；这不代表市场没有变化。维持个人既定计划，不从静态行业评分或旧新闻推导新增买卖动作。"
      : "这些只是机器筛出的候选线索。先打开原文，核对事实、发布日期、数据口径、市场预期差和价格反应；完成前不据此增减仓。",
    opportunities: [],
    riskBoundary: "当前新闻筛选器不具备全文语义、一致预期或因果识别能力，因此不给新闻方向性仓位阈值；应以原文、财报和可复核估值重新建立条件。"
  };
  const failed = results.filter((result) => !result.ok).map((result) => `${result.source.name}: ${result.error}`);
  const watchlist = [
    { label: "国内需求", question: "下次 PMI、社零和工业利润公布后复核", title: "国内需求", trigger: "下次 PMI、社零和工业利润公布后复核", reason: "判断增长改善能否持续" },
    { label: "流动性与利率", question: "关注社融、贷款和政策利率变化", title: "流动性与利率", trigger: "关注社融、贷款和政策利率变化", reason: "决定银行、高股息和成长估值" },
    { label: "海外科技与黄金", question: "跟踪 IMF/OECD 增长、通胀和利率表述", title: "海外科技与黄金", trigger: "跟踪 IMF/OECD 增长、通胀和利率表述", reason: "服务纳斯达克定投与黄金对冲" },
    { label: "消费修复", question: "观察社零、渠道库存和批价", title: "消费修复", trigger: "观察社零、渠道库存和批价", reason: "避免在基本面确认前扩大消费仓位" }
  ];
  const parsedSourceCount = results.filter((result) => result.ok && result.entries.length > 0).length;
  const httpSuccessCount = results.filter((result) => result.ok).length;
  const internationalFailure = results.some((result) => ["IMF", "OECD"].includes(result.source.name) && !result.ok);
  return {
    updatedAt: new Date().toISOString(),
    headline: usedFallback ? `${date} 抓取失败 · 沿用上一版历史快照，未确认新动态` : `${date} 信息检查 · ${noMajorNew ? "今日无重大新增" : `${priorityCandidates.length} 条高优先级候选待核验`} · 当日发布 ${todayEvents.length} 条 · 解析 ${parsedSourceCount}/${results.length} 个来源`,
    global: {
      title: "全球环境",
      detail: globalToday.length ? `机器筛出 ${globalToday.length} 条当日发布候选，原文语义与市场预期尚未核验。${marketDashboard?.analysis?.riskTone ? `行情状态：${marketDashboard.analysis.riskTone}。` : ""}` : internationalFailure ? "未确认到当日发布的全球宏观新报告；IMF/OECD 本次访问失败，历史框架不视作今日更新。" : "未确认到当日发布的全球宏观或科技公司重大信息，历史框架不视作今日更新。",
      impact: "用于校准纳斯达克定投、黄金对冲和海外风险暴露。"
    },
    domestic: {
      title: "国内环境",
      detail: domesticToday.length ? `机器筛出 ${domesticToday.length} 条当日发布候选；原文、预期差和财务影响尚待核验。` : todayEvents.some((event) => event.sourceCategory === "media") ? "未筛出达到门槛的官方或公司级重大公告；媒体线索未用于方向判断。" : "未确认到当日发布的国内官方或公司级重大信息；历史数据保留原发布日期。",
      impact: "用于复核消费、银行、制造业和周期行业的基本面。"
    },
    market: {
      title: "市场含义",
      detail: `${marketConclusion} 当日明确发布日期 ${todayEvents.length} 条、进入高优先级候选 ${priorityCandidates.length} 条；本次解析 ${parsedSourceCount}/${results.length} 个来源，HTTP 成功 ${httpSuccessCount} 个${failed.length ? `，${failed.length} 个访问失败` : ""}。`,
      impact: "先验证订单、现金流和估值，再把新闻转成配置动作。"
    },
    keyEvents: todayEvents,
    marketDashboard: marketDashboard ? { asOf: marketDashboard.asOf, riskTone: marketDashboard.analysis?.riskTone || "未知", conclusion: marketConclusion } : null,
    conclusion,
    assessment,
    watchlist,
    sourceStatus: results.map((result) => ({ id: result.source.id, name: result.source.name, type: result.source.type, sourceType: sourceCategory(result.source), coverage: result.source.coverage || null, url: result.source.url, ok: result.ok, error: result.error || null, entries: result.entries.length })),
    errors: failed,
    fallback: usedFallback
  };
}

function refreshAlipayPlan(data, cognitionRefresh, date, results) {
  if (!data.alipayPlan) return;
  data.alipayPlan.asOf = date;
  data.alipayPlan.signal = cognitionRefresh.conclusion;
  data.alipayPlan.signalSourceCount = results.filter((result) => result.ok).length;
}

function validateSnapshot(data) {
  const warnings = [];
  const companies = Array.isArray(data.companyRankings) ? data.companyRankings : [];
  if (companies.some((item) => item.pe !== null && item.pe !== undefined && Number(item.pe) < 0)) warnings.push("存在负 PE 或亏损公司，估值不可直接比较");
  const extreme = [...(data.globalTech?.companies || []), ...companies].filter((item) => Math.abs(Number(item.profitYoY || 0)) > 500);
  if (extreme.length) warnings.push(`有 ${extreme.length} 条利润同比超过 500%，需要人工核验单位或基期`);
  if (companies.some((item) => !item.announcementDate || !item.source)) warnings.push("部分公司缺少公告日期或原文链接");
  const untraceableTargets = companies.filter((item) => item.targetPrice && (!item.targetPriceSource || !item.targetPriceAsOf));
  if (untraceableTargets.length) warnings.push(`${untraceableTargets.length} 家公司的目标价缺少逐条来源/日期，前台不显示为有效目标价`);
  const unversionedIndustries = (Array.isArray(data.industries) ? data.industries : []).filter((item) => !item.scoreAsOf || !item.scoreMethodology || !item.source);
  if (unversionedIndustries.length) warnings.push(`${unversionedIndustries.length} 个行业缺少评分时点、算法或来源；热图按未核验研究快照呈现`);
  if (companies.length && companies.some((item) => !item.valuationAsOf && !data.meta?.valuationAsOf)) warnings.push("估值字段缺少统一观察时点");
  return warnings;
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp-${process.pid}`;
  fs.writeFileSync(tempPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(tempPath, filePath);
}

function writeSiteData(data) {
  const json = JSON.stringify(data, null, 2);
  const output = `window.__INDUSTRY_RESEARCH__ = ${json};\nwindow.__MACRO_WEEKLY_SITE__ = window.__INDUSTRY_RESEARCH__;\n`;
  const tempPath = `${DATA_FILE}.tmp-${process.pid}`;
  fs.writeFileSync(tempPath, output, "utf8");
  fs.renameSync(tempPath, DATA_FILE);
}

async function main() {
  const publicBuild = path.basename(ROOT) === "github-pages-upload";
  if (publicBuild && process.env.ATLAS_ALLOW_REDACTED_PUBLIC_REFRESH !== "1") {
    throw new Error("Public refresh is disabled unless ATLAS_ALLOW_REDACTED_PUBLIC_REFRESH=1 is set by the sanitized deployment workflow.");
  }
  const args = parseArgs(process.argv.slice(2));
  const data = readSiteData();
  if (publicBuild && (data.portfolio || data.alipayPlan || data.meta?.publicPortfolioData !== "removed")) {
    throw new Error("Public refresh stopped because the site data is not marked as portfolio-redacted.");
  }
  const [results, marketFetch, leaderFetch] = await Promise.all([
    Promise.all(SOURCES.map((source) => fetchSource(source, args.timeout, args.date))),
    fetchMarketData(args.date, args.timeout),
    fetchMarketLeaders(args.date, args.timeout)
  ]);
  const priorMarket = data.marketDashboard;
  const baseMarket = marketFetch.indices.length
    ? marketFetch
    : priorMarket?.indices?.length
      ? { ...priorMarket, fetchedAt: marketFetch.fetchedAt, status: "stale", failures: marketFetch.failures, analysis: { ...(priorMarket.analysis || {}), dataQuality: `本次行情接口未返回有效日线，沿用 ${priorMarket.asOf || "上一交易日"} 快照；${marketFetch.failures.join("、")}` } }
      : marketFetch;
  const marketDashboard = { ...baseMarket, leaders: leaderFetch.leaders.length ? leaderFetch.leaders : (priorMarket?.leaders || []), leaderSource: leaderFetch.source, leaderAnalysis: leaderFetch.leaders.length ? leaderFetch.analysis : (priorMarket?.leaderAnalysis || leaderFetch.analysis), leaderStatus: leaderFetch.status, leaderFailures: leaderFetch.failures };
  if (marketDashboard.status === "fallback") {
    marketDashboard.analysis.dataQuality = `东方财富历史日线接口受限，已用腾讯行情公开接口补齐 ${marketDashboard.indices.length}/${MARKET_INDICES.length} 个当日收盘；5日/20日阶段趋势本次未取得。`;
  }
  if (marketDashboard.indices.length && marketDashboard.leaderAnalysis) {
    marketDashboard.analysis.leaderSummary = `${marketDashboard.leaderAnalysis.consumption}；${marketDashboard.leaderAnalysis.technology}。`;
    marketDashboard.analysis.drivers = [...marketDashboard.analysis.drivers, marketDashboard.analysis.leaderSummary];
    marketDashboard.analysis.dataQuality = [marketDashboard.analysis.dataQuality, marketDashboard.leaderFailures?.length ? `头部报价失败：${marketDashboard.leaderFailures.join("、")}` : "头部报价全部获取成功"].filter(Boolean).join("；");
  }
  const fetchedEvents = makeEvents(results, args.date);
  const usedFallback = fetchedEvents.length === 0;
  const events = usedFallback ? fallbackEvents(data, args.date) : fetchedEvents;
  const cognitionRefresh = buildCognition(data, events, results, args.date, usedFallback, marketDashboard);
  const companyDailyUpdates = buildCompanyDailyUpdates(data, events, args.date);
  updateGlobalTech(data, results, args.date);
  const dailySnapshot = {
    date: args.date,
    generatedAt: cognitionRefresh.updatedAt,
    sourceStatus: cognitionRefresh.sourceStatus,
    events,
    companyDailyUpdates,
    cognitionRefresh,
    marketDashboard
  };

  data.cognitionRefresh = cognitionRefresh;
  data.marketDashboard = marketDashboard;
  data.companyDailyUpdates = companyDailyUpdates;
  refreshAlipayPlan(data, cognitionRefresh, args.date, results);
  if (data.alipayPlan) {
    dailySnapshot.alipayPlan = {
      asOf: data.alipayPlan.asOf,
      signal: data.alipayPlan.signal,
      signalSourceCount: data.alipayPlan.signalSourceCount,
      directions: data.alipayPlan.directions
    };
  }
  data.dailyUpdates = [dailySnapshot, ...(Array.isArray(data.dailyUpdates) ? data.dailyUpdates.filter((item) => item.date !== args.date) : [])].slice(0, 30);
  data.meta = data.meta || {};
  data.meta.generatedAt = cognitionRefresh.updatedAt.replace("T", " ").replace(/\.\d{3}Z$/, " UTC");
  data.meta.updateCadence = "每日检查新闻与行情来源；宏观、行业、财报与估值按各自披露周期更新";
  data.meta.lastDailyUpdate = args.date;
  data.meta.dailyHttpSourceCount = results.filter((result) => result.ok).length;
  data.meta.dailySourceCount = results.filter((result) => result.ok && result.entries.length > 0).length;
  data.meta.marketDataAsOf = marketDashboard.asOf || null;
  data.meta.marketDataFetchedAt = marketDashboard.fetchedAt || null;
  data.meta.marketDataStatus = marketDashboard.status || "failed";
  data.meta.marketDataSource = marketDashboard.source?.name || "未接入";
  data.meta.marketLeaderCount = marketDashboard.leaders?.length || 0;
  data.meta.marketLeaderStatus = marketDashboard.leaderStatus || "failed";
  data.meta.validationWarnings = validateSnapshot(data);

  if (!args.dryRun) {
    writeJsonAtomic(path.join(DAILY_DIR, `${args.date}.json`), dailySnapshot);
    writeSiteData(data);
  }

  logRun(`date=${args.date} dryRun=${args.dryRun} events=${events.length} parsedSources=${results.filter((result) => result.ok && result.entries.length > 0).length}/${results.length} httpOk=${results.filter((result) => result.ok).length}/${results.length} market=${marketDashboard.status}:${marketDashboard.indices.length}/${MARKET_INDICES.length}@${marketDashboard.asOf || "unknown"} marketFailed=${marketDashboard.failures?.join("|") || "none"} leaders=${marketDashboard.leaders?.length || 0}/${MARKET_LEADERS.length} leaderFailed=${marketDashboard.leaderFailures?.join("|") || "none"} failed=${results.filter((result) => !result.ok).map((result) => result.source.name + ":" + result.error).join("|") || "none"}`);
  console.log(JSON.stringify({ date: args.date, dryRun: args.dryRun, events: events.length, succeeded: results.filter((result) => result.ok).length, failed: results.filter((result) => !result.ok).length, siteData: DATA_FILE, dailySnapshot: path.join(DAILY_DIR, `${args.date}.json`) }, null, 2));
}

main().catch((error) => { logRun(`fatal=${error.stack || error.message}`); console.error(`[daily-update] ${error.message}`); process.exitCode = 1; });
