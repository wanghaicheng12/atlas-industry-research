# Public GitHub Pages deployment

This directory is the redacted public package. It intentionally excludes personal holdings, balances, returns, allocation plans, and the personal portfolio pages.

1. The public repository has already been created at `https://github.com/wanghaicheng12/atlas-industry-research`.
2. Upload the contents of this directory to that repository's root, including `.github/workflows/refresh-and-deploy.yml`.
3. Under **Settings → Pages**, set the build and deployment source to **GitHub Actions**.
4. Under **Actions**, run **Refresh redacted Atlas site** once. The workflow updates the public news and market snapshot, checks the redaction marker, commits the new snapshot, and deploys Pages.
5. The Pages URL will be `https://wanghaicheng12.github.io/atlas-industry-research/`. The current sideload APK has this URL preconfigured; change it under **同步网址** only if the repository address changes.

The scheduled workflow runs daily at 08:30 Beijing time. If a source is blocked, its failure is shown in the site's source status; failed sources do not become new events.

The Android APK is under `downloads/Atlas-Research.apk`. The app opens the deployed site for online updates and includes a redacted offline snapshot. The APK is debug-signed for sideloading, not for Google Play distribution.
