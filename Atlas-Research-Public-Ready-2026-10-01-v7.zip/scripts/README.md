# 每日自动更新

`daily-update.js` 是无第三方依赖的公开资料抓取器。它并行读取国家统计局、人民银行、证监会、沪深交易所、巨潮资讯、工信部、中汽协、IMF、OECD，新浪财经 7×24、澎湃新闻财经、财联社财经快讯、同花顺财经，以及 NVIDIA、Apple、Microsoft、TSMC、Samsung、Sony 的公开 IR 页面，优先解析 RSS/Atom，其他页面解析最新链接标题。

财经媒体来源用于补充盘中和宏观时事，不替代官方披露。每个来源在脚本中有三层标识：`type` 是页面展示名称（如“财经媒体”），`sourceType` 是稳定分类（`official`、`international`、`disclosure`、`media`、`company-ir` 等），`keywords` 用于标题和摘要相关性筛选。脚本会按响应声明解码 UTF-8/GBK/GB18030，并过滤备案号、导航、产品菜单、交易所栏目噪音和与投资无关的媒体标题。页面会在“来源状态”中展示成功、失败和抓取条数；新浪财经、澎湃、财联社、同花顺部分页面为动态渲染或有访问频控，失败时保留错误状态并在下一次运行重试。

脚本每次运行会：

1. 把成功解析的动态整理成 `data/cognitionRefresh`，供“认知刷新”栏目使用；每条事件都带原文 URL。
2. 按股票代码生成 `data/companyDailyUpdates`，让每个头部公司详情都有当天检查结果和公告原文入口；没有匹配到新公告时明确标记为“暂无公司级新公告”。
3. 写入 `data/daily/YYYY-MM-DD.json`，保留最近 30 天的 `dailyUpdates` 历史。
4. 更新 `data/site-data.js` 的 `meta.generatedAt`、`lastDailyUpdate` 和来源成功数。
5. 某个来源超时或被拒绝时保留历史站点数据，并在 `cognitionRefresh.sourceStatus/errors` 中标记，下一次运行自动重试；媒体来源成功时会和官方、国际机构、公司 IR 一起进入当天关键变化候选池。

## 本机运行

需要 Node.js 18+（内置 `fetch`）。在 PowerShell 中执行：

```powershell
cd outputs\macro-intelligence-dashboard
.\scripts\daily-update.ps1
```

先检查而不写文件：

```powershell
.\scripts\daily-update.ps1 -DryRun
```

也可以直接运行 Node 脚本：

```powershell
node .\scripts\daily-update.js --date 2026-09-17
```

## 自动化建议

- Windows：在“任务计划程序”创建每日 08:30（Asia/Shanghai）任务，程序填写 `powershell.exe`，参数填写 `-ExecutionPolicy Bypass -File "<站点目录>\scripts\daily-update.ps1"`。
- 当前电脑任务 `Atlas行业基本面每日更新` 每天北京时间 08:30 运行 `daily-task-run.ps1`；日志写入 `scripts/logs/daily-YYYY-MM-DD.log`。任务允许电池供电、错过后补跑，并配置失败重试。
- GitHub Pages：仓库中的 `.github/workflows/daily-refresh.yml` 每天执行抓取并提交 `outputs/macro-intelligence-dashboard/data`；随后由 `deploy-pages.yml` 将 `outputs/macro-intelligence-dashboard/github-pages-upload` 发布到 Pages。抓取任务需要 `contents: write` 才能提交快照。
- Vercel/静态托管：在 CI 中先运行更新脚本，再执行部署。不要把密钥写入站点；当前脚本只访问公开页面。

## 数据边界

网页结构和访问策略可能变化，来源状态必须在页面中显示。抓取到的是标题和原文入口，不替代财报原文、实时行情或投资建议；对于被限流、需要登录或动态渲染的页面，脚本会保留失败状态而不会伪造数据。
