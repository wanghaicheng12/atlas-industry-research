$ErrorActionPreference = "Stop"
$TaskScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TaskSiteDir = Split-Path -Parent $TaskScriptDir
$TaskLogDir = Join-Path $TaskScriptDir "logs"
New-Item -ItemType Directory -Path $TaskLogDir -Force | Out-Null

$TaskDate = Get-Date -Format "yyyy-MM-dd"
$TaskLog = Join-Path $TaskLogDir "daily-$TaskDate.log"
$TaskNodeScript = Join-Path $TaskScriptDir "daily-update.js"
"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')] Atlas daily refresh started" | Add-Content -LiteralPath $TaskLog -Encoding UTF8
try {
  $TaskNodeCommand = Get-Command node -ErrorAction SilentlyContinue
  if (-not $TaskNodeCommand) {
    $TaskNodeCandidates = @(
      "C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe",
      (Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe")
    )
    $TaskNodePath = $TaskNodeCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  } else {
    $TaskNodePath = $TaskNodeCommand.Source
  }
  if (-not $TaskNodePath) { throw "Node.js was not found in PATH or the bundled Codex runtime." }
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')] Using Node: $TaskNodePath" | Add-Content -LiteralPath $TaskLog -Encoding UTF8
} catch {
  $_ | Out-String | Add-Content -LiteralPath $TaskLog -Encoding UTF8
  exit 1
}

Push-Location $TaskSiteDir
try {
  $TaskOutput = & $TaskNodePath $TaskNodeScript --date $TaskDate --timeout 12000 2>&1
  $TaskExitCode = $LASTEXITCODE
  $TaskOutput | Out-File -LiteralPath $TaskLog -Append -Encoding utf8
  if ($TaskExitCode -eq 0) {
    $TaskPublishDir = Join-Path $TaskSiteDir "github-pages-upload"
    $TaskPublishDataDir = Join-Path $TaskPublishDir "data"
    if (Test-Path -LiteralPath $TaskPublishDir) {
      New-Item -ItemType Directory -Path (Join-Path $TaskPublishDataDir "daily") -Force | Out-Null
      Copy-Item -LiteralPath (Join-Path $TaskSiteDir "data\site-data.js") -Destination (Join-Path $TaskPublishDataDir "site-data.js") -Force
      Copy-Item -LiteralPath (Join-Path $TaskSiteDir "data\daily\$TaskDate.json") -Destination (Join-Path $TaskPublishDataDir "daily\$TaskDate.json") -Force
      $TaskMainHash = (Get-FileHash (Join-Path $TaskSiteDir "data\site-data.js")).Hash
      $TaskPublishHash = (Get-FileHash (Join-Path $TaskPublishDataDir "site-data.js")).Hash
      if ($TaskMainHash -ne $TaskPublishHash) { throw "Published site-data.js hash does not match main data" }
      "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')] Published data copy synchronized" | Add-Content -LiteralPath $TaskLog -Encoding UTF8
    }
  }
} catch {
  $_ | Out-String | Add-Content -LiteralPath $TaskLog -Encoding UTF8
  $TaskExitCode = 1
} finally {
  Pop-Location
}

"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')] Atlas daily refresh finished with exit code $TaskExitCode" | Add-Content -LiteralPath $TaskLog -Encoding UTF8
exit $TaskExitCode
