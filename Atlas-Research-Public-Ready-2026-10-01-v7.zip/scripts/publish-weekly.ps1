﻿param(
  [string]$InputDir = (Join-Path $PSScriptRoot "..\weekly-input"),
  [string]$OutputFile = (Join-Path $PSScriptRoot "..\data\site-data.js"),
  [string]$ArchiveDir = (Join-Path $PSScriptRoot "..\data\archive"),
  [string]$PublishDir = (Join-Path $PSScriptRoot "..\github-pages-upload")
)

$ErrorActionPreference = "Stop"

function Ensure-Directory {
  param([string]$DirectoryPath)

  if (-not (Test-Path $DirectoryPath)) {
    New-Item -ItemType Directory -Path $DirectoryPath -Force | Out-Null
  }
}

function Read-SnapshotFiles {
  param([string]$DirectoryPath)

  if (-not (Test-Path $DirectoryPath)) {
    throw "Missing weekly input directory: $DirectoryPath"
  }

  $files = Get-ChildItem -Path $DirectoryPath -Filter "*.json" -File |
    Where-Object { $_.BaseName -ne "TEMPLATE" }

  if ($files.Count -eq 0) {
    throw "No weekly JSON files were found in $DirectoryPath"
  }

  $requiredFields = @(
    "issueId",
    "issueLabel",
    "title",
    "publishedAt",
    "period",
    "nextUpdate",
    "summary"
  )

  $snapshots = foreach ($file in $files) {
    $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
    $snapshot = $content | ConvertFrom-Json

    foreach ($fieldName in $requiredFields) {
      if (-not $snapshot.PSObject.Properties.Name.Contains($fieldName)) {
        throw "Missing required field '$fieldName' in $($file.Name)"
      }

      $value = [string]$snapshot.$fieldName
      if ([string]::IsNullOrWhiteSpace($value)) {
        throw "Empty required field '$fieldName' in $($file.Name)"
      }
    }

    $snapshot
  }

  return $snapshots | Sort-Object { [datetime]$_.publishedAt } -Descending
}

$snapshots = Read-SnapshotFiles -DirectoryPath $InputDir
Ensure-Directory -DirectoryPath (Split-Path $OutputFile -Parent)
Ensure-Directory -DirectoryPath $ArchiveDir

foreach ($snapshot in $snapshots) {
  $archivePath = Join-Path $ArchiveDir "$($snapshot.issueId).json"
  $snapshot | ConvertTo-Json -Depth 100 | Set-Content -Path $archivePath -Encoding UTF8
}

$current = $snapshots[0]
$siteData = [pscustomobject]@{
  meta = [pscustomobject]@{
    siteTitle = "宏观情报周刊"
    tagline = "把快讯、官方数据、国际机构报告和基金方向建议放进同一个可追踪的周更站点。"
    cadence = "每周更新"
    generatedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm 'CST'")
    currentIssue = $current.issueId
    allocationDisclaimer = "以下建议是基于宏观信号框架生成的方向提示，不替代你的风险承受能力评估，也不替代持仓级别的具体投资决策。"
    methodology = @(
      "先看一级快讯，判断市场到底在交易利率、增长、通胀、贸易还是风险偏好。",
      "再用官方统计、央行口径和国际组织材料验证，避免被单一标题带偏。",
      "最后才形成基金方向建议，并明确哪些属于防守仓、进攻仓和观察仓。"
    )
    workflow = @(
      "复制 weekly-input/TEMPLATE.json，填写新一期周刊内容。",
      "优先更新本周快讯、官方验证层、机构报告和基金方向建议。",
      "运行 scripts/publish-weekly.ps1 重新生成 data/site-data.js。",
      "打开 index.html 检查当前期和往期归档是否展示正常。"
    )
    disclaimer = "本周刊优先使用公开和官方来源做验证。涉及 Bloomberg、Reuters、WSJ、CEIC 等订阅型数据时，应通过合法授权获取，当前站点只保留其在研究流程中的优先级位置。"
  }
  snapshots = $snapshots
}

$json = $siteData | ConvertTo-Json -Depth 100
$scriptContent = "window.__MACRO_WEEKLY_SITE__ = $json;"
$scriptContent | Set-Content -Path $OutputFile -Encoding UTF8

Write-Output "Generated site data: $OutputFile"
Write-Output "Current issue: $($current.issueLabel) / $($current.title)"

if (Test-Path $PublishDir) {
  $SiteRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
  $PublishRoot = Resolve-Path $PublishDir
  $FilesToPublish = @(
    "index.html",
    "styles.css",
    "app.js",
    "manifest.webmanifest",
    "service-worker.js",
    "vercel.json"
  )

  foreach ($RelativePath in $FilesToPublish) {
    $SourcePath = Join-Path $SiteRoot $RelativePath
    if (Test-Path $SourcePath) {
      Copy-Item -Path $SourcePath -Destination (Join-Path $PublishRoot $RelativePath) -Force
    }
  }

  foreach ($DirectoryName in @("data", "icons")) {
    $SourceDirectory = Join-Path $SiteRoot $DirectoryName
    $TargetDirectory = Join-Path $PublishRoot $DirectoryName

    if (Test-Path $SourceDirectory) {
      if (Test-Path $TargetDirectory) {
        Remove-Item -Path $TargetDirectory -Recurse -Force
      }

      Copy-Item -Path $SourceDirectory -Destination $TargetDirectory -Recurse -Force
    }
  }

  # Keep the daily refresh entrypoint available when the Pages folder is
  # published as a standalone repository.
  $SourceScripts = Join-Path $SiteRoot "scripts"
  $TargetScripts = Join-Path $PublishRoot "scripts"
  if (Test-Path $SourceScripts) {
    if (Test-Path $TargetScripts) {
      Remove-Item -Path $TargetScripts -Recurse -Force
    }
    Copy-Item -Path $SourceScripts -Destination $TargetScripts -Recurse -Force
  }

  Write-Output "Synced GitHub Pages upload folder: $PublishDir"
}
