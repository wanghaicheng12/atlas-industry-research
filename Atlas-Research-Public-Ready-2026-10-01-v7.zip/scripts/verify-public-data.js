#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");
const PRIVATE_KEYS = new Set(["portfolio", "alipayPlan", "holdings", "newMoneyPlan", "disclosedWeight", "goldWeight", "goldReturn"]);

function assertNoPrivateKeys(value, location) {
  if (Array.isArray(value)) return value.forEach((item, index) => assertNoPrivateKeys(item, `${location}[${index}]`));
  if (!value || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    if (PRIVATE_KEYS.has(key)) throw new Error(`Personal field '${key}' found at ${location}`);
    assertNoPrivateKeys(child, `${location}.${key}`);
  }
}

function readSiteData() {
  const context = { window: {} };
  const file = path.join(ROOT, "data", "site-data.js");
  vm.runInNewContext(fs.readFileSync(file, "utf8"), context, { filename: file });
  return context.window.__INDUSTRY_RESEARCH__;
}

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const file = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(file) : [file];
  });
}

function main() {
  const data = readSiteData();
  if (data?.meta?.publicPortfolioData !== "removed") throw new Error("Public site-data.js lacks the redaction marker");
  assertNoPrivateKeys(data, "site-data");
  const files = walk(path.join(ROOT, "data")).filter((file) => file.endsWith(".json"));
  for (const file of files) assertNoPrivateKeys(JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, "")), file);
  const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
  if (/id="(?:portfolio|alipay)"|data-view="(?:portfolio|alipay)"/.test(html)) throw new Error("Public HTML includes personal portfolio sections");
  console.log(JSON.stringify({ publicDataVerified: true, dailySnapshots: files.filter((file) => file.includes(`${path.sep}daily${path.sep}`)).length }, null, 2));
}

main();
