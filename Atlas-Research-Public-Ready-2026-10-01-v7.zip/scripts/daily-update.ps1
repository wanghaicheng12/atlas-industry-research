param(
  [string]$Date = (Get-Date).ToString("yyyy-MM-dd"),
  [int]$TimeoutMs = 12000,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$NodeScript = Join-Path $ScriptDir "daily-update.js"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js 18 or newer is required. Install Node.js, then run this script again."
}

$Arguments = @($NodeScript, "--date", $Date, "--timeout", $TimeoutMs)
if ($DryRun) { $Arguments += "--dry-run" }

Write-Host "Atlas daily refresh: $Date"
& node @Arguments
if ($LASTEXITCODE -ne 0) {
  throw "daily-update.js failed with exit code $LASTEXITCODE"
}

