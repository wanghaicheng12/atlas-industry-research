const data = window.__INDUSTRY_RESEARCH__ || window.__MACRO_WEEKLY_SITE__;

const state = { industry: "all", stance: "all", companyIndustry: "all", companyCodes: null, sortDesc: true, selectedIndustry: null, selectedCompany: null, query: "" };
const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? "").replace(/[&<>\"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pct = (value) => value === null || value === undefined || value === "" || !Number.isFinite(Number(value)) ? "--" : `${Number(value) > 0 ? "+" : ""}${Number(value).toFixed(1)}%`;
const num = (value) => value === null || value === undefined || value === "" || !Number.isFinite(Number(value)) ? "--" : Number(value).toLocaleString("zh-CN", { maximumFractionDigits: 1 });
const financeIndustry = (item) => /银行|证券|保险/.test(String(item.industry || ""));
const metricText = (item, key, suffix = "") => {
  const value = item[key];
  if (value === null || value === undefined || value === "") return "未披露";
  if (value === 0 && key === "grossMargin" && financeIndustry(item)) return "不适用";
  if (value === 0 && key === "cashflow" && financeIndustry(item)) return "待核验";
  return `${num(value)}${suffix}`;
};
const isGenericDisclosure = (url) => /sse\.com\.cn\/disclosure|szse\.cn\/disclosure|cninfo\.com\.cn\/new\/commonUrl|icbc\.com\.cn\/ICBCLtd\/.*财务报告/i.test(String(url || ""));

function init() {
  if (!data || !Array.isArray(data.industries)) { document.body.innerHTML = "<div style='padding:30px;color:white'>数据文件未生成。</div>"; return; }
  if (!data.portfolio) {
    document.querySelector('[data-view="portfolio"]')?.remove();
    $("portfolio")?.remove();
  }
  if (!data.alipayPlan) {
    document.querySelector('[data-view="alipay"]')?.remove();
    $("alipay")?.remove();
  }
  state.selectedIndustry = null;
  document.title = data.meta?.siteTitle || "Atlas 行业基本面研究台";
  const latestDate = String(data.meta?.lastDailyUpdate || data.meta?.generatedAt || "").slice(0, 10).replace(/-/g, ".");
  const eventCount = data.cognitionRefresh?.keyEvents?.length || 0;
  const sourceStatuses = data.cognitionRefresh?.sourceStatus || [];
  const parsedSourceCount = sourceStatuses.filter((item) => item.ok && Number(item.entries || 0) > 0).length;
  const sourceCount = parsedSourceCount || data.meta?.dailySourceCount || 0;
  const generated = data.meta?.generatedAt || "";
  if ($("syncStatusLabel")) $("syncStatusLabel").textContent = "数据快照已同步";
  if ($("lastUpdateLabel")) $("lastUpdateLabel").textContent = `最近抓取 ${latestDate}`;
  if ($("lastUpdateTime")) $("lastUpdateTime").textContent = generated ? `北京时间 ${formatBeijingTime(generated)}` : "同步时间待确认";
  if ($("lastUpdateSources")) $("lastUpdateSources").textContent = `已解析 ${sourceCount}/${sourceStatuses.length || sourceCount} 个来源`;
  if ($("liveSnapshot")) $("liveSnapshot").textContent = `每日抓取 ${latestDate} · ${sourceCount}/${sourceStatuses.length || sourceCount} 源解析 · 当日新闻 ${data.cognitionRefresh?.keyEvents?.filter((item) => item.publishedAt === data.meta?.lastDailyUpdate).length || 0} 条`;
  if ($("overviewUpdated")) $("overviewUpdated").textContent = `新闻/行情抓取完成 ${formatBeijingTime(generated) || latestDate}`;
  if ($("dailyStamp")) $("dailyStamp").textContent = `DAILY CHECK · ${latestDate}`;
  if ($("signalStatus")) $("signalStatus").textContent = "非综合评分";
  if ($("signalScore")) $("signalScore").textContent = "--";
  if ($("signalBar")) $("signalBar").style.width = "0";
  if ($("signalNarrative")) $("signalNarrative").textContent = `行业评分缺少统一的原始时序与可复现算法，不合成为“基本面温度”。行情抓取 ${data.marketDashboard?.asOf || "未取得"}；估值快照 ${data.meta?.valuationAsOf || "日期未标注"}。`;
  if ($("footerSnapshot")) $("footerSnapshot").textContent = `新闻抓取 ${latestDate} · 行情 ${data.marketDashboard?.asOf || "未取得"} · 其他数据按各自披露期`;
  if ($("valuationAsOfLabel")) $("valuationAsOfLabel").textContent = `PE / 市值快照：${data.meta?.valuationAsOf || "未标注"}；目标价未提供逐条机构来源`;
  $("industryCount").textContent = data.industries.length;
  $("companyCount").textContent = data.companyRankings.length;
  $("opinionCount").textContent = data.opinions.length;
  $("opinionTotal").textContent = data.opinions.length;
  renderKpis(); renderMarketDashboard(); renderMacro(); renderHeatmap(); renderCognition(); renderIndustryFilters(); renderIndustries(); renderGlobalTech(); renderCompanyFilters(); renderCompanies(); renderPortfolio(); renderAlipayPlan(); renderOpinions(); renderSources(); renderPlan(); renderOpportunities(); renderRisks(); bindNavigation();
  $("searchInput").addEventListener("input", (event) => { state.query = event.target.value.trim().toLowerCase(); renderIndustries(); renderCompanies(); renderOpinions(); });
  $("refreshButton").addEventListener("click", (event) => { event.currentTarget.textContent = "…"; window.location.href = `${window.location.pathname}?refresh=${Date.now()}`; });
  $("levelFilter").addEventListener("change", (event) => { state.industry = event.target.value; renderIndustries(); });
  $("stanceFilter").addEventListener("change", (event) => { state.stance = event.target.value; renderIndustries(); });
  $("companyIndustryFilter").addEventListener("change", (event) => {
    state.companyIndustry = event.target.value;
    state.companyCodes = null;
    state.selectedCompany = null;
    const selected = data.industries.find((item) => item.name === state.companyIndustry);
    state.selectedIndustry = selected?.id || null;
    renderIndustries();
    renderCompanies();
  });
  $("sortCompanies").addEventListener("click", () => { state.sortDesc = !state.sortDesc; $("sortCompanies").textContent = state.sortDesc ? "按市值排序 ↕" : "按净利润增速排序 ↕"; renderCompanies(); });
  $("exportPlan").addEventListener("click", exportPlan);
}

function formatBeijingTime(value) {
  if (/T\d{2}:\d{2}/.test(String(value))) {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) return new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }).format(date).replace(/\//g, ".");
  }
  const match = String(value).match(/^(\d{4}-\d{2}-\d{2})\s+(\d{2}):(\d{2})/);
  if (!match) return String(value).replace(" UTC", "");
  const date = new Date(`${match[1]}T${match[2]}:${match[3]}:00Z`);
  if (Number.isNaN(date.getTime())) return String(value).replace(" UTC", "");
  return new Intl.DateTimeFormat("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }).format(date).replace(/\//g, ".");
}

function renderKpis() {
  const kpis = data.meta.kpis || [];
  $("kpiGrid").innerHTML = kpis.map((item) => `<article class="kpi-card"><div class="label"><span>${esc(item.label)}</span><span class="mini-icon">${esc(item.icon || "·")}</span></div><div class="kpi-value">${esc(item.value)}</div><div class="kpi-note">${esc(item.note)}</div></article>`).join("");
}

function marketPct(value) {
  if (value === null || value === undefined || value === "") return "--";
  const number = Number(value);
  if (!Number.isFinite(number)) return "--";
  return `${number >= 0 ? "+" : ""}${number.toFixed(2)}%`;
}

function marketPoint(value) {
  if (value === null || value === undefined || value === "") return "--";
  const number = Number(value);
  return Number.isFinite(number) ? number.toLocaleString("zh-CN", { maximumFractionDigits: 2 }) : "--";
}

function renderMarketDashboard() {
  const market = data.marketDashboard;
  if (!market || !$("marketIndexGrid")) return;
  const analysis = market.analysis || {};
  const indices = market.indices || [];
  const stale = market.status === "stale";
  const fallback = market.status === "fallback";
  const capturedAt = formatBeijingTime(market.fetchedAt || data.meta.generatedAt);
  const attemptedAt = market.refreshAttemptAt ? formatBeijingTime(market.refreshAttemptAt) : null;
  $("marketDashboardAsOf").textContent = `${stale ? "沿用快照" : fallback ? "备用收盘" : "收盘数据"} ${market.asOf || "日期待确认"}`;
  $("marketDashboardSubtitle").textContent = `${market.source?.name || "行情源"} · ${stale ? `数据抓取 ${capturedAt}；本次尝试 ${attemptedAt || "时间未知"}` : `抓取 ${capturedAt}`} · 自动刷新约每小时；不提供逐笔实时行情`;
  $("marketConclusion").textContent = analysis.conclusion || "暂无可核验的行情结论。";
  $("marketDataQuality").textContent = analysis.dataQuality || "行情状态待确认。";
  $("marketBreadth").textContent = `指数样本：${analysis.breadth || "未取得，不做扩散判断"}`;
  $("marketSource").innerHTML = market.source?.url ? `<a href="${esc(market.source.url)}" target="_blank" rel="noreferrer">数据源 ↗</a>` : "数据源待确认";
  $("marketAction").textContent = analysis.action || "维持原定计划，等待更多数据确认。";
  $("marketRisk").textContent = analysis.risk || "单日涨跌不能替代基本面验证。";
  $("marketInvalidation").textContent = analysis.invalidation || "若趋势和盈利预期同时恶化，重新评估仓位。";
  const leaders = market.leaders || [];
  if ($("marketLeaderStatus")) $("marketLeaderStatus").textContent = `${market.leaderStatus === "ok" ? "本次抓取" : "沿用快照/访问失败"} ${leaders.length} 个标的`;
  if ($("marketLeaderGrid")) $("marketLeaderGrid").innerHTML = leaders.length ? leaders.map((item) => { const value = Number(item.changePct); const tone = value >= 0 ? "up" : "down"; const quoteTime = item.quoteTime ? `报价时间 ${item.quoteTime}` : (item.asOf || market.asOf || "最近交易日"); return `<div class="market-leader-row"><div><strong>${esc(item.name)}</strong><span>${esc(item.category)} · ${esc(item.region)} · ${esc(quoteTime)}</span></div><div><b class="${tone}">${marketPoint(item.close)}</b><small class="${tone}">${marketPct(value)}</small></div></div>`; }).join("") : `<div class="empty-state">消费与全球科技头部行情未取得，不生成标的涨跌判断。</div>`;
  $("marketIndexGrid").innerHTML = indices.length ? indices.map((item) => {
    const day = Number(item.changePct);
    const tone = day >= 0 ? "up" : "down";
    const series = (item.series || []).map((point) => point.close);
    const trendAvailable = series.length >= 5 && item.return5d !== null && item.return5d !== undefined && item.return20d !== null && item.return20d !== undefined && Number.isFinite(Number(item.return5d)) && Number.isFinite(Number(item.return20d));
    const metric = (value) => value !== null && value !== undefined && Number.isFinite(Number(value)) ? `<b class="${Number(value) >= 0 ? "up" : "down"}">${marketPct(value)}</b>` : `<b class="unavailable">--</b>`;
    return `<article class="market-index-card"><div class="market-index-head"><div><strong>${esc(item.name)}</strong><span>${esc(item.region || "")} · ${esc(item.unit || "")}</span></div><b class="${tone}">${marketPct(day)}</b></div><div class="market-index-close"><strong>${marketPoint(item.close)}</strong><span>${esc(item.asOf || market.asOf || "最近交易日")}</span></div>${trendAvailable ? sparkline(series, tone) : `<div class="market-trend-unavailable">阶段序列未取得</div>`}<div class="market-index-metrics"><span>5日 ${metric(item.return5d)}</span><span>20日 ${metric(item.return20d)}</span></div></article>`;
  }).join("") : `<div class="empty-state">行情接口未返回有效指数日线，本日不生成涨跌判断。</div>`;
  const ranked = indices.filter((item) => Number.isFinite(Number(item.changePct))).sort((a, b) => Math.abs(Number(b.changePct)) - Math.abs(Number(a.changePct)));
  const maxMove = Math.max(...ranked.map((item) => Math.abs(Number(item.changePct))), 1);
  $("marketChangeBars").innerHTML = ranked.map((item) => { const value = Number(item.changePct); const tone = value >= 0 ? "up" : "down"; return `<div class="market-bar-row"><span>${esc(item.name)}</span><div class="market-bar-track"><i class="${tone}" style="width:${Math.max(8, Math.abs(value) / maxMove * 100)}%"></i></div><b class="${tone}">${marketPct(value)}</b></div>`; }).join("");
}

function renderMacro() {
  $("macroList").innerHTML = (data.macroIndicators || []).map((item) => `<div class="macro-item"><strong>${esc(item.name)}</strong><span class="macro-value ${item.trend === "up" ? "trend-up" : item.trend === "flat" ? "trend-flat" : ""}" style="${item.trend === "up" ? "color:#e05260" : item.trend === "down" ? "color:#35b67a" : ""}">${esc(item.value)}</span><p>${esc(item.period)} · ${esc(item.note)}</p></div>`).join("");
}

function renderHeatmap() {
  $("heatmap").innerHTML = data.industries.map((item) => `<div class="heat-cell ${esc(item.heatClass)} ${state.selectedIndustry === item.id ? "selected" : ""}" data-industry-id="${esc(item.id)}" title="${esc(item.name)}：${esc(item.score)}，点击查看头部公司" role="button" tabindex="0"><strong>${esc(item.shortName || item.name)}</strong><span>${esc(item.score)} · ${esc(item.trendLabel)}</span></div>`).join("");
  document.querySelectorAll(".heat-cell[data-industry-id]").forEach((cell) => {
    const activate = () => selectIndustry(cell.dataset.industryId);
    cell.addEventListener("click", activate);
    cell.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } });
  });
}

function renderCognition() {
  const item = data.cognitionRefresh;
  if (!item) return;
  $("cognitionDate").textContent = `本次抓取 ${formatBeijingTime(item.updatedAt || data.meta.generatedAt)}`;
  $("cognitionHeadline").textContent = item.headline || "全球、国内和市场三层信息，每天先更新结论再决定是否行动。";
  $("cognitionConclusion").textContent = item.conclusion || "保持信息敏感，但只对已验证的变化调整仓位。";
  const assessment = item.assessment || {};
  const insight = item.investmentInsight || item.investmentConclusion || {};
  const insightHeadline = assessment.stance || (typeof insight === "string" ? insight : (insight.headline || insight.title || "先验证证据，再讨论仓位"));
  const insightText = assessment.investmentImplication || (typeof insight === "string" ? insight : (insight.summary || insight.detail || "结合订单、现金流和估值确认后再行动。"));
  $("cognitionActionHeadline").textContent = insightHeadline;
  $("cognitionActionText").textContent = insightText;
  const opportunities = assessment.opportunities || item.opportunities || (item.keyEvents || []).map((event) => event.opportunity).filter(Boolean).slice(0, 4);
  $("cognitionOpportunityTags").innerHTML = opportunities.map((opportunity) => `<span>${esc(typeof opportunity === "string" ? opportunity : opportunity.title || opportunity.name || "观察机会")}</span>`).join("");
  const normalize = (value, fallbackTitle) => typeof value === "string" ? { title: fallbackTitle, detail: value, impact: "请结合原始数据和资产暴露复核。" } : (value || {});
  const blocks = [["cognitionGlobal", normalize(item.global, "全球环境")], ["cognitionDomestic", normalize(item.domestic, "国内环境")], ["cognitionMarket", normalize(item.market, "市场含义")]];
  blocks.forEach(([id, block]) => { $(`${id}Title`).textContent = block.title || "暂无标题"; $(`${id}`).textContent = block.detail || "暂无摘要"; $(`${id}Impact`).textContent = block.impact || "待补充资产影响"; });
  const eventsHtml = (item.keyEvents || []).map((event) => { const analysis = [event.investmentInsight ? `证据要求：${event.investmentInsight}` : "", event.opportunity ? `机会核验：${event.opportunity}` : "", event.risk ? `风险核验：${event.risk}` : "", event.invalidation ? `失效条件：${event.invalidation}` : ""].filter(Boolean).join(" · "); const dateLabel = event.publishedAt ? `发布 ${event.publishedAt}` : `抓取 ${event.time || "今日"}`; return `<div class="cognition-event"><time>${esc(dateLabel)}</time><div><div class="cognition-event-meta"><span>${esc(event.sourceName || "公开来源")}</span><span>${esc(event.topic || event.sourceCategory || "信息")}</span><b>${esc(event.reviewStatus || event.impact || "方向待核验")}</b></div><h4>${esc(event.title)}</h4><p>${esc(event.detail)} </p>${analysis ? `<div class="cognition-event-insight"><span>投研核验</span><p>${esc(analysis)}</p></div>` : ""}</div><a href="${esc(event.source || "#")}" target="_blank" rel="noreferrer">原文 ↗</a></div>`; }).join("");
  $("cognitionEvents").innerHTML = eventsHtml || `<div class="empty-state">${esc(item.conclusion || "今日无重大新增。")}</div>`;
  $("cognitionWatchlist").innerHTML = (item.watchlist || []).map((watch) => { const value = typeof watch === "string" ? { label: "观察", question: watch } : watch; return `<li><span>${esc(value.label || value.title || "观察")}</span>${esc(value.question || value.trigger || value.reason || "")}</li>`; }).join("");
}

function renderGlobalTech() {
  const tech = data.globalTech || data.globalTechGiants;
  if (!tech) return;
  $("techSummaryTitle").textContent = "各公司财报期不同 · 日常抓取不更新财务指标";
  $("techSummaryText").textContent = `${tech.asOfNote || "财务数据须按每家公司披露期和原文核对"}。历史增长率、PE 与行业叙事不等于当日更新或投资评级。`;
  const companies = tech.companies || tech.giants || [];
  const status = tech.sourceStatus || [];
  const irOk = status.filter((item) => item.ok).length;
  $("techSummaryStats").innerHTML = [["跟踪巨头", companies.length], ["IR访问成功", `${irOk}/${status.length || companies.length}`], ["统一财报日期", tech.fundamentalsAsOf || "各公司披露期不同"]].map(([label, value]) => `<div><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`).join("");
  const quotes = data.marketDashboard?.leaders || [];
  const quoteName = { "英伟达": "英伟达", "苹果": "苹果", "微软": "微软", "台积电": "台积电", "三星电子": "三星电子", "索尼集团": "索尼集团" };
  $("techGrid").innerHTML = companies.map((item) => { const quote = quotes.find((entry) => entry.name === quoteName[item.name] && entry.category === "全球科技"); const move = quote && Number.isFinite(Number(quote.changePct)) ? Number(quote.changePct) : null; const tone = move === null ? "flat" : move >= 0 ? "up" : "down"; const revenueColor = Number(item.revenueYoY || 0) >= 0 ? "#e05260" : "#35b67a"; const profitColor = Number(item.profitYoY || 0) >= 0 ? "#e05260" : "#35b67a"; const quality = item.dataQuality || (Math.abs(Number(item.profitYoY || 0)) > 500 ? "极端同比增速，需人工复核原始公告单位" : "财务数据按披露期展示；非每日更新"); const moveMarkup = move === null ? `<span class="tech-move unavailable">无可核验当日行情</span>` : `<span class="tech-move ${tone}" title="${esc(quote.asOf)} · ${esc(quote.sourceName)}">${move >= 0 ? "+" : ""}${move.toFixed(2)}%</span>`; const trendMarkup = item.trendAsOf ? sparkline(item.trend || [], tone) : `<div class="market-trend-unavailable">未提供带日期的历史价格序列</div>`; const peValue = item.pe && item.peAsOf && item.peSource ? `${num(item.pe)}x` : "来源/时点缺失"; return `<article class="tech-card"><div class="tech-card-head"><div class="tech-company"><div class="tech-logo">${esc(item.logo || item.ticker || item.name?.slice(0, 2))}</div><div><strong>${esc(item.name)}</strong><span>${esc(item.ticker || "")} · ${esc(item.region || item.theme || "全球科技")}</span></div></div>${moveMarkup}</div>${trendMarkup}<div class="tech-metrics"><div><span>最新披露</span><strong>${esc(item.reportPeriod || "披露期未标注")}</strong></div><div><span>营收增速</span><strong style="color:${revenueColor}">${pct(item.revenueYoY || 0)}</strong></div><div><span>${esc(item.profitMetric || "净利")}增速</span><strong style="color:${profitColor}">${pct(item.profitYoY || 0)}</strong></div></div>${quality ? `<div class="data-quality-warning">${esc(quality)}</div>` : ""}<p class="tech-thesis">${esc(item.thesis || item.reason || "关注资本开支兑现、产品周期、区域收入与估值。")}</p><div class="tech-foot"><span>PE ${esc(peValue)}</span><a href="${esc(item.source || item.ir || "#")}" target="_blank" rel="noreferrer">公司 IR ↗</a></div></article>`; }).join("");
  const moves = tech.dailyMoves || tech.moves || tech.daily || [];
  $("techMovesList").innerHTML = moves.map((item) => `<div class="tech-move-item"><time>${esc(item.date || item.time || "今日")}</time><div><h4>${esc(item.title || item.name || "公司动态")}</h4><p>${esc(item.summary || item.detail || "打开公司 IR 查看最新披露。")}</p></div><a href="${esc(item.source || "#")}" target="_blank" rel="noreferrer">原文 ↗</a></div>`).join("");
}

function renderIndustryFilters() {
  const levels = [...new Set(data.industries.map((item) => item.level1))];
  $("levelFilter").innerHTML = `<option value="all">全部一级行业</option>${levels.map((item) => `<option value="${esc(item)}">${esc(item)}</option>`).join("")}`;
}

function visibleIndustries() {
  return data.industries.filter((item) => {
    const text = `${item.name} ${item.level1} ${item.level2}`.toLowerCase();
    return (!state.query || text.includes(state.query)) && (state.industry === "all" || item.level1 === state.industry) && (state.stance === "all" || item.stance === state.stance);
  });
}

function renderIndustries() {
  const items = visibleIndustries();
  $("industryGrid").innerHTML = items.length ? items.map(industryCard).join("") : `<div class="empty-state">没有匹配的行业，请调整筛选条件。</div>`;
  document.querySelectorAll(".industry-card").forEach((card) => card.addEventListener("click", () => selectIndustry(card.dataset.id)));
}

function selectIndustry(industryId) {
  const item = data.industries.find((entry) => entry.id === industryId);
  if (!item) return;
  state.selectedIndustry = item.id;
  state.companyIndustry = item.name;
  state.companyCodes = Array.isArray(item.companies) ? item.companies.slice() : null;
  state.selectedCompany = null;
  state.industry = "all";
  state.stance = "all";
  // A clicked radar represents a deliberate scope change; remove a prior global search term.
  state.query = "";
  if ($("searchInput")) $("searchInput").value = "";
  if ($("levelFilter")) $("levelFilter").value = "all";
  if ($("stanceFilter")) $("stanceFilter").value = "all";
  renderHeatmap();
  if ($("companyIndustryFilter")) $("companyIndustryFilter").value = item.name;
  renderIndustries();
  renderCompanies();
  $("companies").scrollIntoView({ behavior: "smooth", block: "start" });
}

function industryCard(item) {
  const toneColor = item.scoreTone === "up" ? "#e05260" : item.scoreTone === "down" ? "#35b67a" : "#e5c477";
  const hasDatedTrend = Boolean(item.trendAsOf && item.trendDates?.length === item.trend?.length);
  const trendMarkup = hasDatedTrend ? sparkline(item.trend, item.scoreTone) : `<div class="market-trend-unavailable">评分与序列缺少观测日期/可复现口径</div>`;
  return `<article class="industry-card ${state.selectedIndustry === item.id ? "selected" : ""}" data-id="${esc(item.id)}"><div class="industry-top"><div><span class="industry-code">${esc(item.code)} · ${esc(item.level1)}</span><h3>${esc(item.name)}</h3><span class="industry-sub">${esc(item.level2)}</span></div><span class="stance ${esc(item.stance)}">快照 · ${esc(item.stanceLabel)}</span></div><div class="industry-score"><strong>${esc(item.score)}</strong><span class="score-${esc(item.scoreTone)}" style="color:${toneColor}">${esc(item.trendLabel)} · 分数变化 ${Number(item.scoreChange) >= 0 ? "+" : ""}${num(item.scoreChange)}分</span></div>${trendMarkup}<div class="industry-metrics"><div><span>营收增速 · 时点待核</span><strong style="color:${item.metrics.revenueYoY >= 0 ? "#e05260" : "#35b67a"}">${pct(item.metrics.revenueYoY)}</strong></div><div><span>利润增速 · 时点待核</span><strong style="color:${item.metrics.profitYoY >= 0 ? "#e05260" : "#35b67a"}">${pct(item.metrics.profitYoY)}</strong></div><div><span>PE · 时点待核</span><strong>${esc(item.metrics.pe)}x</strong></div></div><div class="industry-card-foot"><span>龙头 ${esc(item.companies.length)} 家</span><b>查看详情 →</b></div></article>`;
}

function sparkline(values, tone) {
  const points = (values || [40, 42, 41, 44, 46]).map(Number); const min = Math.min(...points); const max = Math.max(...points); const range = max - min || 1;
  const coords = points.map((value, index) => `${(index / (points.length - 1)) * 100},${31 - ((value - min) / range) * 25}`).join(" ");
  const color = tone === "up" ? "#e05260" : tone === "flat" ? "#e5c477" : "#35b67a";
  return `<svg class="sparkline" viewBox="0 0 100 35" preserveAspectRatio="none" aria-hidden="true"><polyline points="${coords}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke"/><circle cx="${((points.length-1)/(points.length-1))*100}" cy="${31-((points[points.length-1]-min)/range)*25}" r="2.4" fill="${color}"/></svg>`;
}

function renderCompanyFilters() {
  const options = [...new Set(data.companyRankings.map((item) => item.industry))];
  $("companyIndustryFilter").innerHTML = `<option value="all">全部行业</option>${options.map((item) => `<option value="${esc(item)}">${esc(item)}</option>`).join("")}`;
}

function visibleCompanies() {
  let rows = data.companyRankings.filter((item) => { const text = `${item.name} ${item.industry} ${item.code}`.toLowerCase(); const inSelectedIndustry = !state.companyCodes || state.companyCodes.includes(item.code); return (!state.query || text.includes(state.query)) && inSelectedIndustry && (state.companyIndustry === "all" || item.industry === state.companyIndustry); });
  rows.sort((a, b) => state.sortDesc ? b.marketCap - a.marketCap : b.profitYoY - a.profitYoY); return rows;
}

function renderCompanies() {
  const rows = visibleCompanies();
  $("companyTable").innerHTML = rows.length ? rows.map(companyRow).join("") : `<div class="empty-state">没有匹配的公司。</div>`;
  const selected = state.companyIndustry === "all" ? "全部行业" : state.companyIndustry;
  const scope = $("companyScopeNote") || document.querySelector("#companies .section-head p");
  if (scope) scope.textContent = state.companyIndustry === "all" ? "按市值与行业代表性选取龙头，指标来自最新年报、半年报、业绩快报或预告。" : `已筛选「${selected}」头部公司 · 共 ${rows.length} 家；点击公司行查看财报摘要与原文。`;
  document.querySelectorAll(".company-row").forEach((row) => { const activate = () => { state.selectedCompany = row.dataset.code; renderCompanies(); renderCompanyDetail(data.companyRankings.find((item) => item.code === state.selectedCompany)); }; row.addEventListener("click", activate); row.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } }); });
  if (state.selectedCompany) renderCompanyDetail(data.companyRankings.find((item) => item.code === state.selectedCompany));
  else renderCompanyDetail(null);
}

function companyRow(item) {
  const isActive = state.selectedCompany === item.code;
  const revenueColor = item.revenueYoY >= 0 ? "#e05260" : "#35b67a"; const profitColor = item.profitYoY >= 0 ? "#e05260" : "#35b67a";
  const valuationNote = item.valuationAsOf || data.meta?.valuationAsOf || "研究快照待核验";
  const consensusVerified = Boolean(item.consensusSource && item.consensusAsOf);
  return `<div class="company-row ${isActive ? "active" : ""}" data-code="${esc(item.code)}" role="button" tabindex="0" aria-label="查看 ${esc(item.name)} 详情"><div class="company-cell"><div class="company-logo">${esc(item.logo || item.name.slice(0,1))}</div><div class="company-name"><strong>${esc(item.name)}</strong><span>${esc(item.code)} · ${esc(item.industry)}</span></div></div><div class="cell-main">${esc(item.reportPeriod || "未标注")}</div><div class="cell-main">${num(item.revenue)}<small class="${item.revenueYoY >= 0 ? "up" : "down"}" style="color:${revenueColor}">${pct(item.revenueYoY)}</small></div><div class="cell-main">${num(item.profit)}<small class="${item.profitYoY >= 0 ? "up" : "down"}" style="color:${profitColor}">${pct(item.profitYoY)}</small></div><div class="cell-main">${metricText(item, "grossMargin", "%")}</div><div class="cell-main">${metricText(item, "roe", "%")}</div><div class="cell-main" title="${esc(valuationNote)}">${esc(item.pe)}x</div><div title="${consensusVerified ? esc(item.consensusAsOf) : "缺少逐条机构来源和日期"}"><span class="tag-consensus ${consensusVerified ? (item.consensusTone || "") : "unverified"}">${consensusVerified ? esc(item.consensus) : "未核验"}</span></div></div>`;
}

function renderCompanyDetail(item) {
  const panel = $("companyDetail"); if (!item) { panel.classList.remove("visible"); return; } panel.classList.add("visible");
  const update = (data.companyDailyUpdates || []).find((entry) => entry.code === item.code);
  const noMatch = update && /暂无公司级新公告/.test(update.title || "");
  const updateMarkup = update ? `<div class="company-update ${noMatch ? "update-unmatched" : ""}"><div class="company-update-head"><span>${noMatch ? "抓取状态 · 未匹配到" : "最新动向"} · ${esc(update.date)}</span><span class="update-impact">${esc(update.impact || "中性")}</span></div><h4>${esc(update.title || "公司最新动态")}</h4><p>${esc(update.summary || "暂无摘要，请打开原文核对。")}</p><a class="source-link" href="${esc(update.source || item.source)}" target="_blank" rel="noreferrer">${esc(update.sourceName || "查看公告原文")} ↗</a></div>` : "";
  const consensusVerified = Boolean(item.consensusSource && item.consensusAsOf);
  const sourceLabel = isGenericDisclosure(item.source) ? "公司公告查询入口（未定位本次财报）↗" : "披露来源链接（请核对报告期）↗";
  const cashflowLabel = metricText(item, "cashflow", "亿");
  const targetPriceLabel = item.targetPrice && item.targetPriceSource && item.targetPriceAsOf ? `¥${num(item.targetPrice)}` : "来源/时点缺失";
  panel.innerHTML = `<div class="detail-head"><div class="detail-title"><div class="company-logo">${esc(item.logo || item.name.slice(0,1))}</div><div><h3>${esc(item.name)} <span style="color:#718892;font-size:12px;font-weight:400">${esc(item.code)}</span></h3><p>${esc(item.industry)} · ${esc(item.reportPeriod || "报告期未标注")} · 公告 ${esc(item.announcementDate || "日期未标注")} · 估值快照 ${esc(item.valuationAsOf || data.meta?.valuationAsOf || "时点未标注")}</p></div></div><a class="source-link" href="${esc(item.source)}" target="_blank" rel="noreferrer">${sourceLabel}</a></div><div class="detail-body"><div><p class="detail-copy">${esc(item.reason)}</p><p class="detail-copy">机构评级与目标价：${consensusVerified ? esc(item.consensusDetail || item.consensus) : "当前无逐条机构原文及评级日期，按未核验数据处理"}。目标价：${targetPriceLabel}。</p></div><div class="detail-kpis"><div class="detail-kpi"><span>营收（亿元）</span><strong>${metricText(item, "revenue")}</strong></div><div class="detail-kpi"><span>归母净利（亿元）</span><strong>${metricText(item, "profit")}</strong></div><div class="detail-kpi"><span>经营现金流（亿元）</span><strong>${cashflowLabel}</strong></div><div class="detail-kpi"><span>毛利率</span><strong>${metricText(item, "grossMargin", "%")}</strong></div></div></div>${updateMarkup}`;
}

function renderPortfolio() {
  const portfolio = data.portfolio;
  if (!portfolio) return;
  if ($("portfolioSnapshotLabel")) $("portfolioSnapshotLabel").textContent = `持仓截图快照 · ${portfolio.asOf || "日期未提供"} · 仅含截图可见持仓`;
  const holdings = portfolio.holdings || [];
  const existingHoldings = holdings.filter((item) => Number(item.amount || 0) > 0);
  const total = existingHoldings.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const weighted = total ? existingHoldings.reduce((sum, item) => sum + Number(item.amount || 0) * Number(item.currentReturn || 0), 0) / total : 0;
  const kpis = [
    ["截图可见持仓", `¥${Math.round(total).toLocaleString("zh-CN")}`, `${existingHoldings.length} 只基金 · 已披露权重 ${portfolio.disclosedWeight}%`],
    ["持仓加权收益", `${weighted >= 0 ? "+" : ""}${weighted.toFixed(2)}%`, "按截图金额加权，未包含未展示资产"],
    ["黄金对冲仓", `${portfolio.goldWeight}%`, `当前收益 ${portfolio.goldReturn >= 0 ? "+" : ""}${portfolio.goldReturn.toFixed(2)}%`],
    ["定投主线", "纳斯达克", "建议继续定投，分 4 个月投入新增资金"]
  ];
  $("portfolioKpis").innerHTML = kpis.map(([label, value, note]) => `<article class="kpi-card"><div class="label"><span>${esc(label)}</span><span class="mini-icon">◫</span></div><div class="kpi-value">${esc(value)}</div><div class="kpi-note">${esc(note)}</div></article>`).join("");
  const maxWeight = Math.max(...existingHoldings.map((item) => Number(item.weight || 0)), 1);
  $("portfolioBars").innerHTML = existingHoldings.map((item) => { const loss = Number(item.currentReturn) < 0; const gold = item.category === "黄金"; const color = loss ? "#35b67a" : "#e05260"; return `<div class="bar-row"><span class="bar-label">${esc(item.shortName || item.name)}</span><div class="bar-track"><div class="bar-fill ${loss ? "loss" : gold ? "gold" : ""}" style="width:${Math.max(8, Number(item.weight) / maxWeight * 100)}%"></div></div><span class="bar-value ${loss ? "loss" : "gain"}" style="color:${color}">${Number(item.currentReturn) >= 0 ? "+" : ""}${Number(item.currentReturn).toFixed(1)}%</span></div>`; }).join("") + `<div class="bar-legend"><span><i style="background:#e05260"></i>持仓收益为正（红）</span><span><i style="background:#35b67a"></i>持仓收益为负（绿）</span><span><i style="background:#a58a4f"></i>黄金</span></div>`;
  const actionsCurrent = /^\d{4}-\d{2}-\d{2}$/.test(String(portfolio.asOf || ""));
  $("portfolioTable").innerHTML = `<div class="fund-row head"><span>基金</span><span>金额</span><span>权重</span><span>持有收益</span><span>${actionsCurrent ? "复核状态" : "历史动作标注"}</span></div>` + holdings.map((item) => { const color = Number(item.currentReturn) >= 0 ? "#e05260" : "#35b67a"; const action = actionsCurrent ? item.action : "快照过期 · 待重评"; return `<div class="fund-row"><div class="fund-name"><strong>${esc(item.name)}</strong><span>${esc(item.category)} · ${esc(item.plan)}</span></div><span class="fund-num">¥${Number(item.amount).toLocaleString("zh-CN", {maximumFractionDigits: 0})}</span><span class="fund-num">${Number(item.weight).toFixed(2)}%</span><span class="fund-num fund-return ${item.currentReturn >= 0 ? "gain" : "loss"}" style="color:${color}">${item.currentReturn >= 0 ? "+" : ""}${Number(item.currentReturn).toFixed(2)}%</span><span class="fund-action ${actionsCurrent ? (item.actionTone || "") : ""}">${esc(action)}</span></div>`; }).join("");
  renderPortfolioRadar(portfolio.radar || []);
  $("portfolioPlan").innerHTML = (portfolio.newMoneyPlan || []).map((item) => `<article class="portfolio-plan-card"><div class="plan-percent">${esc(item.percent)}%</div><h4>${esc(item.title)}</h4><p>${esc(item.amount)}</p><strong>${esc(item.action)}</strong><p class="trigger">触发：${esc(item.trigger)}</p></article>`).join("");
}

function renderPortfolioRadar(values) {
  const labels = values.map((item) => item.label); const points = values.map((item) => Number(item.value)); const cx = 150, cy = 132, radius = 93;
  const polar = (value, index, r = radius) => { const angle = -Math.PI / 2 + index * (Math.PI * 2 / points.length); return [cx + Math.cos(angle) * r * value / 100, cy + Math.sin(angle) * r * value / 100]; };
  const polygon = (factor) => points.map((_, index) => polar(100, index, radius * factor).join(",")).join(" "); const shape = points.map((value, index) => polar(value, index).join(",")).join(" ");
  const axes = labels.map((_, index) => { const [x, y] = polar(100, index); return `<line class="radar-axis" x1="${cx}" y1="${cy}" x2="${x}" y2="${y}"/>`; }).join(""); const text = labels.map((label, index) => { const [x, y] = polar(116, index); const anchor = x < cx - 6 ? "end" : x > cx + 6 ? "start" : "middle"; return `<text class="radar-label" x="${x}" y="${y}" text-anchor="${anchor}">${esc(label)}</text>`; }).join(""); const dots = points.map((value, index) => { const [x, y] = polar(value, index); return `<circle class="radar-point" cx="${x}" cy="${y}" r="3"/>`; }).join("");
  $("portfolioRadar").innerHTML = `<svg viewBox="0 0 300 265" role="img" aria-label="组合因子雷达图"><polygon class="radar-grid" points="${polygon(1)}"/><polygon class="radar-grid" points="${polygon(.66)}"/><polygon class="radar-grid" points="${polygon(.33)}"/>${axes}<polygon class="radar-shape" points="${shape}"/>${dots}${text}</svg>`;
}

function renderAlipayPlan() {
  const plan = data.alipayPlan;
  if (!plan) return;
  const budgetInput = $("alipayBudget");
  const riskSelect = $("alipayRisk");
  const recalculate = () => {
    const budget = Math.max(500, Math.min(100000, Number(budgetInput.value) || plan.defaultBudget || 7500));
    const risk = riskSelect.value || plan.defaultRisk || "balanced";
    const profile = plan.riskProfiles?.[risk] || plan.riskProfiles?.balanced || {};
    const weights = profile.weights || {};
    budgetInput.value = budget;
    $("alipayAsOf").textContent = plan.asOf || data.meta.lastDailyUpdate || "--";
    $("alipaySignal").textContent = plan.signal || "保持分散，等待数据确认后再提高进攻仓位。";
    $("alipaySignalMeta").textContent = `${profile.label || "平衡"}档 · 月度预算 ¥${budget.toLocaleString("zh-CN")} · ${plan.signalSourceCount || 0} 个公开来源已刷新`;
    $("alipayDirectionGrid").innerHTML = (plan.directions || []).map((item) => {
      const percent = Number(weights[item.id] ?? item.percent ?? 0);
      const amount = Math.round(budget * percent / 100);
      return `<article class="alipay-direction-card"><div class="alipay-direction-top"><span class="alipay-direction-role">${esc(item.role)}</span><span class="alipay-direction-percent">${percent}%</span></div><h3>${esc(item.title)}</h3><p class="alipay-direction-category">${esc(item.category)} · ${esc(item.alipayTag)}</p><div class="alipay-amount"><strong>¥${amount.toLocaleString("zh-CN")}</strong><span>每月建议</span></div><div class="alipay-progress"><i style="width:${percent}%"></i></div><p class="alipay-direction-copy">${esc(item.reason)}</p><div class="alipay-trigger"><span>触发条件</span>${esc(item.trigger)}</div></article>`;
    }).join("");
    $("alipayRules").innerHTML = (plan.rules || []).map((item) => `<div class="alipay-rule"><span>${esc(item.label)}</span><p>${esc(item.detail)}</p></div>`).join("");
    $("alipayBalance").innerHTML = (plan.boundaries || []).map((item) => `<div class="alipay-balance-item"><span>${esc(item.label)}</span><strong>${esc(item.value)}</strong><p>${esc(item.detail)}</p></div>`).join("");
  };
  recalculate();
  budgetInput.addEventListener("change", recalculate);
  riskSelect.addEventListener("change", recalculate);
  $("alipayRecalculate").addEventListener("click", recalculate);
  $("exportAlipayPlan").addEventListener("click", () => {
    const budget = Math.max(500, Math.min(100000, Number(budgetInput.value) || plan.defaultBudget || 7500));
    const risk = riskSelect.value || plan.defaultRisk || "balanced";
    const profile = plan.riskProfiles?.[risk] || plan.riskProfiles?.balanced || {};
    const lines = (plan.directions || []).map((item, index) => { const percent = Number(profile.weights?.[item.id] ?? item.percent ?? 0); return `${index + 1}. ${item.title} ${percent}% · ¥${Math.round(budget * percent / 100).toLocaleString("zh-CN")} / 月\n   ${item.trigger}`; }).join("\n");
    const blob = new Blob([`支付宝基金投资方向规划\n更新：${plan.asOf || data.meta.lastDailyUpdate}\n风险档位：${profile.label || risk}\n月度预算：¥${budget.toLocaleString("zh-CN")}\n\n${lines}`], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "alipay-fund-direction-plan.txt"; link.click(); URL.revokeObjectURL(url);
  });
}

function renderOpinions() {
  const opinions = data.opinions.filter((item) => !state.query || `${item.institution} ${item.title} ${item.industry}`.toLowerCase().includes(state.query));
  $("opinionList").innerHTML = opinions.map((item) => `<article class="opinion-card"><div class="opinion-card-top"><div class="opinion-source"><div class="source-mark">${esc(item.mark || item.institution.slice(0,2))}</div><div><strong>${esc(item.institution)}</strong><span>${esc(item.type)} · ${esc(item.industry)}</span></div></div><span class="opinion-date">${esc(item.date)}</span></div><h3>${esc(item.title)}</h3><p>${esc(item.summary)}</p><div class="opinion-foot"><span class="opinion-chip">原文摘要 · 方向待复核</span><a class="opinion-view" href="${esc(item.source)}" target="_blank" rel="noreferrer">阅读来源 ↗</a></div></article>`).join("");
}

function renderSources() {
  const statusMap = new Map((data.cognitionRefresh?.sourceStatus || []).map((item) => [item.name, item]));
  const statuses = data.cognitionRefresh?.sourceStatus || [];
  const warnings = data.meta?.validationWarnings || [];
  const httpOk = statuses.filter((item) => item.ok).length;
  const parsed = statuses.filter((item) => item.ok && item.entries > 0).length;
  const warningMarkup = warnings.length ? `<div class="source-health-warning">数据校验：${esc(warnings.join("；"))}</div>` : "";
  $("sourceHealth").innerHTML = statuses.length
    ? `<div class="source-health-summary"><strong>${httpOk}/${statuses.length}</strong><span>HTTP访问成功</span><small>${parsed} 个来源解析出条目；未解析不等于“没有新消息”</small></div>${warningMarkup}`
    : warningMarkup;
  $("sourceList").innerHTML = (data.sources || []).map((item) => {
    const status = statusMap.get(item.name);
    const label = !status ? "未纳入今日抓取" : !status.ok ? `访问失败 · ${status.error || "需重试"}` : status.entries > 0 ? `HTTP成功 · 解析 ${status.entries} 条候选` : "HTTP成功 · 未解析到条目";
    const stateClass = !status ? "unknown" : !status.ok ? "failed" : status.entries > 0 ? "ok" : "empty";
    return `<div class="source-item"><span class="source-type">${esc(item.type)}</span><a href="${esc(item.url)}" target="_blank" rel="noreferrer"><span>${esc(item.name)}</span><span>↗</span></a><div class="source-status ${stateClass}">${esc(label)}</div><p>${esc(item.description)}</p></div>`;
  }).join("");
}
function renderPlan() {
  const today = String(data.meta?.lastDailyUpdate || new Date().toISOString().slice(0, 10));
  const year = today.slice(0, 4);
  $("planList").innerHTML = (data.researchPlan || []).map((item) => {
    const due = /^\d{4}-\d{2}-\d{2}$/.test(item.date) ? item.date : `${year}-${String(item.date || "").replace(/^\/?/, "").replace("/", "-")}`;
    const expired = !item.done && /^\d{4}-\d{2}-\d{2}$/.test(due) && due < today;
    const status = item.done ? "已完成" : expired ? "计划日期已过 · 未核销" : due === today ? "计划日期为今日 · 未核销" : "计划项 · 未自动核销";
    return `<div class="plan-item"><div class="plan-date">${esc(item.date)}<span>${esc(item.owner)}</span></div><div class="plan-content"><div style="display:flex;gap:8px;align-items:flex-start"><div><h3>${esc(item.title)}</h3><p>${esc(item.action)}</p><p class="plan-source">验证源：${esc(item.source)} · ${status}</p></div><div class="plan-check">${item.done ? "✓" : ""}</div></div></div></div>`;
  }).join("");
}
function renderOpportunities() { $("opportunityGrid").innerHTML = (data.opportunityPoints || []).map((item) => `<article class="opportunity-card"><span class="opportunity-window">研究假设 · 基础数据日期未标注</span><h3>${esc(item.title)}</h3><p>${esc(item.thesis)}</p><p class="opportunity-action"><b>旧计划动作（未核验，不是当前建议）：</b>${esc(item.action)}</p></article>`).join(""); }
function renderRisks() { $("riskList").innerHTML = (data.meta.risks || []).map((item) => `<div class="risk-item"><i>!</i><p>${esc(item)}</p></div>`).join(""); }

function bindNavigation() {
  const labels = { overview: "总览", marketDashboard: "每日股市变化", cognition: "每日认知", industries: "行业雷达", "global-tech": "全球科技", companies: "公司业绩", portfolio: "我的基金", alipay: "支付宝规划", opinions: "机构观点", plan: "研究计划" };
  document.querySelectorAll("[data-scroll]").forEach((button) => button.addEventListener("click", () => $(button.dataset.scroll).scrollIntoView({ behavior: "smooth" })));
  document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => { const id = button.dataset.view; $(id).scrollIntoView({ behavior: "smooth" }); document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item === button)); $("crumb").textContent = labels[id]; }));
  const sections = [...document.querySelectorAll(".view-section")]; const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) { const id = entry.target.id; document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === id)); $("crumb").textContent = labels[id] || "总览"; } }), { rootMargin: "-35% 0px -55% 0px" }); sections.forEach((section) => observer.observe(section));
}

function exportPlan() { const content = (data.researchPlan || []).map((item, index) => `${index + 1}. [${item.date}] ${item.title}\n   ${item.action}\n   验证源：${item.source}`).join("\n"); const blob = new Blob([`ATLAS 研究参考计划\n数据快照：${data.meta.generatedAt}\n\n${content}`], { type: "text/plain;charset=utf-8" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "atlas-research-plan.txt"; link.click(); URL.revokeObjectURL(url); }

init();
