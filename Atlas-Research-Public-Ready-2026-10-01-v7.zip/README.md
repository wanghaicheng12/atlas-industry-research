# Atlas Public Research Snapshot

Public macro, market, industry and company research snapshots.

This public copy excludes personal portfolio holdings, amounts, returns, allocation plans and account-specific actions. Daily refresh checks news and market sources; it does not imply that macro, industry, financial-statement or valuation datasets were updated.

Machine-filtered headlines are research candidates, not verified direction calls. Verify primary sources, reporting periods, valuation dates and risk conditions before making decisions.

## Publish and sync
See [`PUBLIC-DEPLOYMENT.md`](PUBLIC-DEPLOYMENT.md) to publish this redacted directory and enable daily GitHub Pages refresh.

The Android APK is under `downloads/Atlas-Research.apk`. It opens this site's HTTPS URL for daily synchronization and also contains a redacted offline snapshot.
